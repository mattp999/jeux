"""Tous les dessins du jeu, faits en code : Licorne (d'après le doudou), Capy le capybara,
les muffins à l'herbe aux pépites de chocolat, et le décor de prairie."""
import math
import random

import pygame

from commun import vivid, star_points

# les couleurs du doudou
LILAS = (190, 176, 230)
LILAS_D = (150, 134, 200)
LILAS_L = (212, 202, 242)
CREME = (250, 244, 222)
CREME_D = (226, 214, 186)
ROSE = (238, 110, 130)
ROSE_L = (248, 170, 186)
NOIR = (24, 22, 34)
ARC = [(240, 90, 110), (250, 160, 70), (250, 220, 80), (110, 210, 140), (110, 170, 240), (220, 130, 200)]


CORNE = [(236, 130, 160), (110, 170, 240), (110, 210, 140), (250, 220, 80), (250, 160, 70), (240, 90, 110)]


def _corne(s, base, tip, w):
    """La corne arc-en-ciel, comme le doudou : rose à la base, puis bleu, vert, jaune, orange, et rouge au bout."""
    bx, by = base
    tx, ty = tip
    n = len(CORNE)
    for i in range(n):
        k0, k1 = i / n, (i + 1) / n
        p0 = (bx + (tx - bx) * k0, by + (ty - by) * k0)
        p1 = (bx + (tx - bx) * k1, by + (ty - by) * k1)
        w0, w1 = w * (1 - k0 * 0.85), w * (1 - k1 * 0.85)
        dx, dy = ty - by, -(tx - bx)
        d = math.hypot(dx, dy) or 1
        dx, dy = dx / d, dy / d
        pts = [(p0[0] + dx * w0, p0[1] + dy * w0), (p1[0] + dx * w1, p1[1] + dy * w1),
               (p1[0] - dx * w1, p1[1] - dy * w1), (p0[0] - dx * w0, p0[1] - dy * w0)]
        pygame.draw.polygon(s, CORNE[i], pts)
    pygame.draw.circle(s, CORNE[-1], (int(tx), int(ty)), max(2, int(w * 0.18)))


def _oreille(s, cx, cy, ang, back=False):
    """Oreille lilas en pointe, avec l'intérieur rose. (cx, cy) : le bas de l'oreille ; ang : penchée (degrés)."""
    a = math.radians(ang)

    def shape(w, h, dy=0):
        pts = []
        for k in range(9):                       # bord gauche, de la base jusqu'à la pointe
            t = k / 8
            pts.append((-w * (1 - t) ** 0.9 * (1 + 0.25 * math.sin(math.pi * t)), -h * t))
        for k in range(8, -1, -1):               # bord droit, de la pointe jusqu'à la base
            t = k / 8
            pts.append((w * (1 - t) ** 0.9 * (1 + 0.25 * math.sin(math.pi * t)), -h * t))
        return [(cx + x * math.cos(a) - (y + dy) * math.sin(a), cy + x * math.sin(a) + (y + dy) * math.cos(a)) for x, y in pts]
    pygame.draw.polygon(s, LILAS_D if back else LILAS, shape(15, 34))
    pygame.draw.polygon(s, ROSE, shape(8, 24, -3))


def licorne_side(expr="normal", leg=0):
    """Licorne de profil, à 4 pattes, tournée vers la droite (260 x 180).
    expr : normal, happy (yeux en arc), squash (yeux plissés).  leg : 0 ou 1 (elle trotte)."""
    s = pygame.Surface((260, 180), pygame.SRCALPHA)
    up = (0, 7) if leg else (7, 0)
    TOP = 22                                     # place en haut pour la grande corne
    HD = 14                                      # la tête est un peu moins haute par rapport au corps
    # les 4 petites pattes (celles de derrière un peu plus foncées)
    for x, l, d in ((58, up[1], True), (150, up[0], True), (82, up[0], False), (174, up[1], False)):
        pygame.draw.ellipse(s, LILAS_D if d else LILAS, (x, 136 - l, 34, 40))
        pygame.draw.ellipse(s, LILAS_D, (x, 160 - l, 34, 16))
    # une petite queue rose
    for (x, y, r) in ((30, 92, 13), (22, 106, 11), (26, 120, 9)):
        pygame.draw.circle(s, ROSE, (x, y), r)
    # le corps, bien rond
    pygame.draw.ellipse(s, LILAS_D, (40, 58, 164, 104))
    pygame.draw.ellipse(s, LILAS, (43, 60, 158, 98))
    pygame.draw.ellipse(s, LILAS_L, (68, 70, 86, 28))
    # la tête (avec la crinière) : dessinée à part, puis posée un peu plus bas sur le corps
    hs = pygame.Surface((260, 180), pygame.SRCALPHA)
    body, s = s, hs
    # la crinière rose sur le haut du cou
    for (x, y, r) in ((150, 46, 15), (140, 62, 14), (132, 78, 13)):
        pygame.draw.circle(s, ROSE, (x, y), r)
        pygame.draw.circle(s, ROSE_L, (x - 3, y - 4), r // 3)
    # la tête, devant
    _oreille(s, 182, 34, 22, back=True)
    pygame.draw.circle(s, LILAS_D, (180, 66), 48)
    pygame.draw.circle(s, LILAS, (180, 66), 45)
    pygame.draw.ellipse(s, LILAS_L, (158, 32, 40, 22))
    _oreille(s, 160, 34, -16)
    # le gros museau crème
    pygame.draw.ellipse(s, CREME_D, (200, 50, 56, 52))
    pygame.draw.ellipse(s, CREME, (202, 51, 52, 48))
    pygame.draw.ellipse(s, ROSE_L, (240, 62, 9, 12))
    if expr == "squash":
        pygame.draw.arc(s, ROSE, (214, 72, 30, 18), math.pi * 1.1, math.pi * 1.9, 3)
    else:
        pygame.draw.arc(s, ROSE, (212, 66, 36, 26), math.pi * 1.1, math.pi * 1.95, 3)
    if expr == "happy":
        pygame.draw.arc(s, NOIR, (184, 44, 20, 16), 0.3, math.pi - 0.3, 4)
    elif expr == "squash":
        pygame.draw.line(s, NOIR, (184, 48), (202, 54), 4)
        pygame.draw.line(s, NOIR, (184, 60), (202, 54), 4)
    else:
        pygame.draw.circle(s, NOIR, (194, 52), 8)
        pygame.draw.circle(s, (255, 255, 255), (197, 48), 3)
    s = body
    s.blit(hs, (0, HD))
    out = pygame.Surface((260, 180 + TOP), pygame.SRCALPHA)
    out.blit(s, (0, TOP))
    _corne(out, (176, 26 + TOP + HD), (198, HD), 16)        # la grande corne arc-en-ciel
    return vivid(out, 0.25)


def licorne_front(expr="normal"):
    """Licorne de face (pour les menus et la fête), 200 x 200."""
    s = pygame.Surface((200, 200), pygame.SRCALPHA)
    pygame.draw.ellipse(s, LILAS_D, (40, 150, 46, 40))
    pygame.draw.ellipse(s, LILAS_D, (114, 150, 46, 40))
    pygame.draw.ellipse(s, LILAS_D, (30, 96, 140, 92))
    pygame.draw.ellipse(s, LILAS, (34, 98, 132, 86))
    for (x, y, r) in ((136, 30, 14), (150, 44, 12), (62, 34, 11)):
        pygame.draw.circle(s, ROSE, (x, y), r)
    _oreille(s, 60, 46, -32)
    _oreille(s, 140, 46, 32)
    pygame.draw.circle(s, LILAS_D, (100, 90), 62)
    pygame.draw.circle(s, LILAS, (100, 90), 59)
    pygame.draw.ellipse(s, LILAS_L, (66, 44, 60, 28))
    # les yeux
    for ex in (68, 132):
        if expr == "happy":
            pygame.draw.arc(s, NOIR, (ex - 11, 78, 22, 16), 0.3, math.pi - 0.3, 4)
        else:
            pygame.draw.circle(s, NOIR, (ex, 88), 10)
            pygame.draw.circle(s, (255, 255, 255), (ex + 3, 84), 3)
    # le museau
    pygame.draw.ellipse(s, CREME_D, (64, 92, 72, 62))
    pygame.draw.ellipse(s, CREME, (66, 93, 68, 58))
    pygame.draw.ellipse(s, ROSE_L, (80, 108, 8, 12))
    pygame.draw.ellipse(s, ROSE_L, (112, 108, 8, 12))
    pygame.draw.arc(s, ROSE, (80, 112, 40, 28), math.pi * 1.1, math.pi * 1.9, 3)
    # les pattes avant
    pygame.draw.ellipse(s, LILAS_D, (24, 128, 34, 30))
    pygame.draw.ellipse(s, LILAS_D, (142, 128, 34, 30))
    out = pygame.Surface((200, 222), pygame.SRCALPHA)
    out.blit(s, (0, 22))
    _corne(out, (100, 36 + 22), (100, 0), 17)              # la grande corne arc-en-ciel
    return vivid(out, 0.25)


BEIGE = (214, 172, 122)
BEIGE_D = (176, 132, 86)
BEIGE_L = (232, 200, 156)
BRUN = (138, 88, 52)
BRUN_D = (100, 62, 36)
BLANC = (250, 250, 246)
BLANC_D = (222, 222, 216)


def _oreille_capuche(s, cx, base, ang, length=26, width=12):
    """Une oreille blanche de la capuche : fine et bien dressée. (cx, base) : le bas de l'oreille ;
    ang : un tout petit peu penchée (degrés) ; length : environ 1/3 de la hauteur de la tête."""
    e = pygame.Surface((width + 4, length + 4), pygame.SRCALPHA)
    pygame.draw.ellipse(e, BLANC_D, (0, 0, width + 4, length + 4))
    pygame.draw.ellipse(e, BLANC, (2, 2, width, length))
    pygame.draw.ellipse(e, (245, 215, 215), (width // 2 - 1, 7, 6, length - 12))      # l'intérieur, un peu rosé
    e = pygame.transform.rotate(e, ang)
    a = math.radians(ang)
    mx, my = cx - math.sin(a) * length / 2, base - math.cos(a) * length / 2           # le milieu de l'oreille
    s.blit(e, e.get_rect(center=(mx, my)))


def _gourde(s, x, y, k=1.0):
    """La gourde de Capychou : brune avec des petits ronds, le bouchon blanc et la paille jaune en haut.
    (x, y) : le milieu de la gourde."""
    pygame.draw.rect(s, BRUN_D, (x - 15 * k, y - 16 * k, 30 * k, 34 * k), border_radius=int(12 * k))
    pygame.draw.rect(s, BRUN, (x - 13 * k, y - 14 * k, 26 * k, 30 * k), border_radius=int(11 * k))
    for (dx, dy, c) in ((-5, -4, (240, 236, 228)), (5, 2, BRUN_D), (-3, 8, (240, 236, 228))):
        pygame.draw.ellipse(s, c, (x + dx * k - 3 * k, y + dy * k - 3 * k, 6 * k, 7 * k))
    pygame.draw.ellipse(s, BLANC_D, (x - 15 * k, y - 22 * k, 30 * k, 12 * k))           # le bouchon blanc
    pygame.draw.ellipse(s, BLANC, (x - 13 * k, y - 21 * k, 26 * k, 10 * k))
    pygame.draw.line(s, (220, 200, 90), (x + 2 * k, y - 18 * k), (x + 9 * k, y - 34 * k), int(6 * k))   # la paille jaune
    pygame.draw.line(s, (250, 232, 120), (x + 2 * k, y - 18 * k), (x + 9 * k, y - 34 * k), int(3 * k))


def capy(expr="normal", leg=0):
    """Capychou de profil, assis sur ses deux pattes arrière, tourné vers la gauche (150 x 180).
    Beige, museau brun foncé, petits yeux, capuche blanche à grandes oreilles et joues rouges,
    et sa gourde (paille jaune en haut) dans les mains."""
    s = pygame.Surface((150, 180), pygame.SRCALPHA)
    TOP = 30                                     # place en haut pour les oreilles dressées
    # les deux grosses pattes arrière, à plat
    pygame.draw.ellipse(s, BRUN, (34, 158 - (4 if leg else 0), 50, 20))
    pygame.draw.ellipse(s, BRUN_D, (66, 160, 50, 18))
    # le corps assis, tout rond et debout
    pygame.draw.ellipse(s, BEIGE_D, (30, 66, 104, 108))
    pygame.draw.ellipse(s, BEIGE, (33, 68, 98, 102))
    pygame.draw.ellipse(s, BEIGE_L, (40, 86, 40, 60))
    # la tête : capuche blanche, visage beige vers la gauche
    pygame.draw.ellipse(s, BLANC_D, (38, 10, 84, 76))
    pygame.draw.ellipse(s, BLANC, (40, 12, 80, 72))
    pygame.draw.ellipse(s, BEIGE_D, (20, 28, 72, 56))
    pygame.draw.ellipse(s, BEIGE, (22, 30, 68, 52))
    pygame.draw.rect(s, BRUN, (14, 44, 34, 32), border_radius=14)        # le museau brun foncé
    pygame.draw.line(s, NOIR, (20, 54), (25, 56), 3)                      # la narine
    if expr == "happy":
        pygame.draw.arc(s, NOIR, (50, 42, 12, 9), 0.3, math.pi - 0.3, 3)
    else:
        pygame.draw.ellipse(s, NOIR, (52, 44, 8, 6))                     # le petit œil
    # la gourde dans ses mains, et ses petits bras qui la tiennent
    _gourde(s, 40, 114, 0.95)
    pygame.draw.ellipse(s, BEIGE_D, (44, 106, 34, 20))
    # les deux oreilles de la capuche, fines et dressées (1/3 de la hauteur de la tête), derrière la tête
    out = pygame.Surface((150, 180 + TOP), pygame.SRCALPHA)
    _oreille_capuche(out, 92, 18 + TOP, -6, 26, 11)
    _oreille_capuche(out, 70, 16 + TOP, 4, 26, 11)
    out.blit(s, (0, TOP))
    return vivid(out, 0.3)


def capy_front(expr="normal"):
    """Capychou de face (pour les menus et les dialogues), 200 x 200."""
    s = pygame.Surface((200, 200), pygame.SRCALPHA)
    # (les oreilles dépassent un peu en haut : le dessin est posé 14 pixels plus bas à la fin)
    pygame.draw.ellipse(s, BRUN, (40, 172, 40, 24))
    pygame.draw.ellipse(s, BRUN, (120, 172, 40, 24))
    pygame.draw.ellipse(s, BEIGE_D, (26, 92, 148, 100))
    pygame.draw.ellipse(s, BEIGE, (29, 94, 142, 94))
    # la capuche blanche, avec ses deux oreilles fines et dressées (1/3 de la hauteur de la tête)
    for side in (-1, 1):
        _oreille_capuche(s, 100 + side * 34, 40, -side * 6, 38, 15)
    pygame.draw.ellipse(s, BLANC_D, (28, 26, 144, 110))
    pygame.draw.ellipse(s, BLANC, (30, 28, 140, 106))
    # le visage beige, le museau brun foncé avec le nez en Y
    pygame.draw.ellipse(s, BEIGE_D, (44, 52, 112, 92))
    pygame.draw.ellipse(s, BEIGE, (46, 54, 108, 88))
    for ex in (74, 126):
        pygame.draw.ellipse(s, NOIR, (ex - 5, 78, 10, 7))                   # les petits yeux (pas de sourcils)
    pygame.draw.ellipse(s, BRUN, (68, 88, 64, 50))
    pygame.draw.line(s, NOIR, (100, 98), (100, 108), 3)
    pygame.draw.line(s, NOIR, (100, 98), (93, 92), 3)
    pygame.draw.line(s, NOIR, (100, 98), (107, 92), 3)
    pygame.draw.line(s, NOIR, (86, 116), (90, 120), 3)
    pygame.draw.line(s, NOIR, (114, 116), (110, 120), 3)
    # la gourde dans ses mains
    _gourde(s, 100, 162, 1.1)
    for side in (-1, 1):
        pygame.draw.ellipse(s, BRUN, (100 + side * 34 - 14, 150, 28, 22))   # ses petites mains brunes
    full = pygame.Surface((200, 214), pygame.SRCALPHA)
    full.blit(s, (0, 14))
    return vivid(full, 0.3)


def muffin(size=56):
    """Muffin à l'herbe (vert) avec des pépites de chocolat, dans sa caissette."""
    s = pygame.Surface((80, 80), pygame.SRCALPHA)
    # la caissette rayée
    pygame.draw.polygon(s, (230, 150, 170), [(16, 44), (64, 44), (58, 76), (22, 76)])
    for x in range(20, 62, 7):
        pygame.draw.line(s, (200, 110, 140), (x, 46), (x + (40 - x) * 0.15, 75), 2)
    # le dessus vert, bien gonflé
    for (x, y, r) in ((24, 40, 14), (40, 30, 18), (56, 40, 14), (40, 44, 16)):
        pygame.draw.circle(s, (70, 150, 60), (x, y), r + 2)
    for (x, y, r) in ((24, 40, 14), (40, 30, 18), (56, 40, 14), (40, 44, 16)):
        pygame.draw.circle(s, (120, 200, 90), (x, y), r)
    pygame.draw.ellipse(s, (170, 230, 140), (28, 18, 20, 10))
    # les pépites de chocolat
    rng = random.Random(4)
    for _ in range(9):
        x, y = rng.randint(16, 62), rng.randint(20, 48)
        pygame.draw.ellipse(s, (80, 46, 24), (x, y, 7, 5))
    return pygame.transform.smoothscale(vivid(s, 0.3), (size, size))


def caisse_muffins(size=64):
    s = pygame.Surface((64, 64), pygame.SRCALPHA)
    pygame.draw.rect(s, (150, 100, 50), (2, 6, 60, 56), border_radius=6)
    pygame.draw.rect(s, (210, 160, 90), (7, 11, 50, 46), border_radius=4)
    pygame.draw.line(s, (150, 100, 50), (7, 34), (57, 34), 4)
    m = muffin(26)
    s.blit(m, (19, 0))
    return pygame.transform.smoothscale(s, (size, size))


def rainbow_arc(w, h, alpha=255):
    """Un arc-en-ciel (demi-cercle de bandes de couleur)."""
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    band = max(6, w // 26)
    for i, c in enumerate(ARC):
        r = pygame.Rect(i * band, i * band, w - 2 * i * band, 2 * (h - i * band))
        pygame.draw.ellipse(s, c + (alpha,), r, band)
    return s


def tree(seed=1, leaves=None, dots=(130, 220, 120)):
    rng = random.Random(seed)
    leaves = leaves or ((70, 170, 80), (90, 190, 90), (60, 150, 70))
    s = pygame.Surface((180, 240), pygame.SRCALPHA)
    pygame.draw.rect(s, (120, 82, 50), (78, 120, 24, 120), border_radius=8)
    pygame.draw.rect(s, (150, 104, 64), (84, 120, 8, 120))
    for _ in range(9):
        x, y, r = rng.randint(40, 140), rng.randint(30, 130), rng.randint(32, 48)
        pygame.draw.circle(s, rng.choice(leaves), (x, y), r)
    for _ in range(5):
        pygame.draw.circle(s, dots, (rng.randint(50, 130), rng.randint(30, 110)), 10)
    return vivid(s, 0.3)


def flower(col):
    s = pygame.Surface((20, 26), pygame.SRCALPHA)
    pygame.draw.line(s, (60, 140, 60), (10, 26), (10, 10), 2)
    for k in range(5):
        a = k * math.tau / 5
        pygame.draw.circle(s, col, (int(10 + math.cos(a) * 5), int(9 + math.sin(a) * 5)), 4)
    pygame.draw.circle(s, (255, 230, 90), (10, 9), 3)
    return s


def make_tiles():
    rng = random.Random(3)
    T = 64

    def dirt():
        s = pygame.Surface((T, T))
        s.fill((150, 108, 70))
        for _ in range(10):
            pygame.draw.ellipse(s, rng.choice(((128, 90, 58), (170, 126, 86))), (rng.randrange(T), rng.randrange(T), 8, 5))
        return s
    tops = []
    for _ in range(3):
        s = dirt()
        pygame.draw.rect(s, (70, 160, 70), (0, 0, T, 20))
        pygame.draw.rect(s, (110, 200, 90), (0, 0, T, 13))
        for i in range(0, T, 5):
            pygame.draw.line(s, (150, 225, 120), (i, 3), (i + 2, 9), 2)
        if rng.random() < 0.6:
            s.blit(flower(rng.choice(((250, 120, 170), (255, 255, 255), (250, 210, 80), (180, 140, 250)))), (rng.randint(4, 40), -12))
        tops.append(vivid(s, 0.25))
    log = pygame.Surface((T, T), pygame.SRCALPHA)                      # petit tronc couché (on saute par-dessus)
    pygame.draw.rect(log, (110, 74, 44), (2, 26, 60, 38), border_radius=14)
    pygame.draw.rect(log, (150, 104, 64), (6, 30, 52, 30), border_radius=12)
    pygame.draw.circle(log, (200, 160, 110), (54, 45), 12)
    pygame.draw.circle(log, (150, 104, 64), (54, 45), 6, 2)
    hedge = pygame.Surface((T, T))                                      # grande haie (Boulet de canon !)
    hedge.fill((50, 130, 60))
    for _ in range(14):
        pygame.draw.circle(hedge, rng.choice(((70, 160, 70), (40, 110, 50), (90, 180, 80))), (rng.randrange(T), rng.randrange(T)), rng.randint(8, 14))
    return {"top": tops, "dirt": [vivid(dirt(), 0.25) for _ in range(3)], "log": vivid(log, 0.3), "hedge": vivid(hedge, 0.3)}


THEMES = [
    # 0 : la prairie au grand soleil (ciel bleu)
    dict(sky=((140, 200, 250), (230, 240, 230)), far=(120, 190, 150), mid=(100, 190, 100), stars=0,
         leaves=None, dots=(130, 220, 120), flowers=((250, 120, 170), (255, 255, 255), (250, 210, 80))),
    # 1 : les vallées à l'après-midi doré (ciel jaune-orangé, arbres un peu dorés)
    dict(sky=((250, 205, 120), (255, 240, 200)), far=(170, 190, 110), mid=(140, 190, 70), stars=0,
         leaves=((120, 170, 60), (160, 190, 60), (220, 170, 60)), dots=(250, 220, 110),
         flowers=((255, 255, 255), (250, 210, 80), (240, 140, 60))),
    # 2 : le chemin des arcs-en-ciel au coucher du soleil (ciel rose et violet, arbres en fleurs, étoiles)
    dict(sky=((150, 120, 220), (255, 180, 190)), far=(150, 130, 200), mid=(110, 160, 140), stars=26,
         leaves=((240, 150, 200), (250, 180, 220), (200, 120, 190)), dots=(255, 230, 245),
         flowers=((250, 120, 200), (190, 140, 250), (255, 255, 255))),
]


def make_background(w, h, seed=1, theme=0):
    """La prairie : ciel, vallées et collines au loin, arcs-en-ciel, arbres. theme : le décor du niveau."""
    th = THEMES[theme % len(THEMES)]
    rng = random.Random(seed)
    sky = pygame.Surface((w, h))
    (r0, g0, b0), (r1, g1, b1) = th["sky"]
    for y in range(h):
        k = y / h
        sky.fill((int(r0 + (r1 - r0) * k), int(g0 + (g1 - g0) * k), int(b0 + (b1 - b0) * k)), (0, y, w, 1))
    for _ in range(th["stars"]):                                         # les premières étoiles du soir
        x, y = rng.randrange(w), rng.randint(10, 260)
        pygame.draw.polygon(sky, (255, 250, 210), star_points(x, y, rng.randint(4, 8)))
    for _ in range(6):
        x, y = rng.randrange(w), rng.randint(40, 220)
        for dx, r in ((0, 34), (30, 42), (64, 32), (34, 26)):
            pygame.draw.circle(sky, (255, 255, 255), (x + dx, y), r)
    far = pygame.Surface((w, h), pygame.SRCALPHA)
    arc = rainbow_arc(520, 260, 150)
    far.blit(arc, (w - 640, h - 520))
    for i in range(7):                                                   # collines bleutées (les vallées)
        x = i * w / 6 + rng.randint(-60, 60)
        r = rng.randint(220, 340)
        pygame.draw.ellipse(far, th["far"], (x - r, h - 330, r * 2, 520))
    mid = pygame.Surface((w, h), pygame.SRCALPHA)
    for i in range(6):
        x = i * w / 6 + rng.randint(-40, 40)
        r = rng.randint(180, 260)
        pygame.draw.ellipse(mid, th["mid"], (x - r, h - 230, r * 2, 400))
    for i in range(5):
        t = tree(seed * 10 + i, th["leaves"], th["dots"])
        mid.blit(t, (i * w / 5 + rng.randint(0, 120), h - 330))
    near = pygame.Surface((w, h), pygame.SRCALPHA)
    for _ in range(18):
        near.blit(flower(rng.choice(th["flowers"])), (rng.randrange(w), h - rng.randint(28, 40)))
    return tuple(vivid(x, 0.2) for x in (sky, far, mid, near))


def cloud_puff(r=40):
    s = pygame.Surface((r * 3, r * 2), pygame.SRCALPHA)
    for dx, dy, rr in ((r, r, r * 0.8), (r * 1.6, r * 0.8, r), (r * 2.2, r * 1.1, r * 0.7)):
        pygame.draw.circle(s, (255, 255, 255, 235), (int(dx), int(dy)), int(rr))
    return s


def star_icon(full=True, size=40):
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size / 2
    pygame.draw.polygon(s, (200, 140, 20) if full else (120, 120, 140), star_points(c, c + 1, size * 0.48))
    pygame.draw.polygon(s, (255, 220, 60) if full else (190, 190, 205), star_points(c, c + 1, size * 0.38))
    return s


def pad():
    """Le tremplin arc-en-ciel : ici, on fait le Boulet de canon !"""
    s = pygame.Surface((110, 40), pygame.SRCALPHA)
    for i, c in enumerate(ARC):
        pygame.draw.rect(s, c, (6 + i * 3, 10 + i * 4, 98 - i * 6, 8), border_radius=4)
    return s


def catapult():
    """Le lance-nuage du jeu 2 : un gros nuage sur un pied, avec un élastique arc-en-ciel."""
    s = pygame.Surface((160, 220), pygame.SRCALPHA)
    pygame.draw.rect(s, (150, 104, 64), (70, 90, 20, 130), border_radius=8)
    pygame.draw.line(s, (150, 104, 64), (80, 110), (36, 40), 14)
    pygame.draw.line(s, (150, 104, 64), (80, 110), (124, 40), 14)
    for x in (36, 124):
        for dx, r in ((0, 22), (-14, 16), (14, 16)):
            pygame.draw.circle(s, (255, 255, 255), (x + dx, 36), r)
    return s


def balloon(col):
    s = pygame.Surface((50, 90), pygame.SRCALPHA)
    pygame.draw.line(s, (90, 90, 90), (25, 56), (25, 90), 2)
    pygame.draw.ellipse(s, col, (4, 0, 42, 54))
    pygame.draw.polygon(s, col, [(20, 52), (30, 52), (25, 60)])
    pygame.draw.ellipse(s, (255, 255, 255), (12, 8, 10, 14))
    return s
