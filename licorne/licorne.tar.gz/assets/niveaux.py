"""Les 3 niveaux de « L'aventure » et les manches du « Lance-nuage ».

Légende des cases (aventure) :
  #  sol (herbe)      L  petit tronc couché (on saute par-dessus)     H  grande haie (Boulet de canon !)
  m  muffin à l'herbe aux pépites de chocolat        B  caisse de muffins (le Boulet de canon la casse)
  P  tremplin arc-en-ciel : FIRE dessus = BOULET DE CANON (vers la case donnée par pad())
  C  Capychou le capybara (petites bêtises)   K  drapeau arc-en-ciel   F  le grand arc-en-ciel d'arrivée   @  départ
Les sauts sont petits (un peu plus d'une case) : les grandes haies et les grandes vallées se passent au Boulet de canon.
"""


class LB:
    def __init__(self, w, h=12):
        self.w, self.h = w, h
        self.gy = h - 2
        self.g = [[" "] * w for _ in range(h)]
        self.pads = {}

    def _set(self, x, row, ch):
        if 0 <= x < self.w and 0 <= row < self.h:
            self.g[row][x] = ch

    def ground(self, x0, x1):
        for x in range(x0, x1):
            for r in range(self.gy, self.h):
                self._set(x, r, "#")

    def hill(self, x0, x1, k):
        for x in range(x0, x1):
            for r in range(self.gy - k, self.h):
                self._set(x, r, "#")

    def put(self, x, k, ch):
        self._set(x, self.gy - k, ch)

    def items(self, x, k, n, ch="m", step=1):
        for i in range(n):
            self.put(x + i * step, k, ch)

    def hedge(self, x, n=2, k=3):
        for i in range(n):
            for kk in range(1, k + 1):
                self.put(x + i, kk, "H")

    def pad(self, x, to):
        self.put(x, 1, "P")
        self.pads[x] = to

    def done(self, **kw):
        d = dict(grid=["".join(r) for r in self.g], pads=self.pads, w=self.w, h=self.h)
        d.update(kw)
        return d


def level1():
    b = LB(150)
    b.ground(0, 150)
    b.put(3, 1, "@")
    b.items(7, 1, 4)
    b.put(13, 1, "L")
    b.items(15, 2, 3)
    b.put(20, 1, "L")
    b.items(23, 1, 5)
    b.put(30, 1, "C")
    b.items(34, 1, 3)
    b.pad(38, 46)
    b.hedge(41, 2)
    b.items(41, 5, 3, step=2)
    b.put(48, 1, "B")
    b.put(52, 1, "K")
    b.items(55, 1, 4)
    b.hill(60, 63, 1)
    b.items(60, 2, 3)
    b.put(66, 1, "L")
    b.items(68, 1, 4)
    b.put(74, 1, "C")
    b.items(78, 2, 3)
    b.pad(82, 92)
    b.hedge(85, 3)
    b.items(84, 5, 5, step=2)
    b.put(94, 1, "B")
    b.items(97, 1, 5)
    b.put(103, 1, "L")
    b.put(108, 1, "C")
    b.put(112, 1, "K")
    b.items(115, 1, 6)
    b.put(122, 1, "B")
    b.items(126, 2, 3)
    b.put(131, 1, "L")
    b.items(134, 1, 4)
    b.put(142, 1, "F")
    return b.done(name="1  La prairie aux muffins", intro=[
        ("licorne", "Oh ! Des muffins à l'herbe aux pépites de chocolat partout dans la prairie ! Miam !"),
        ("capy", "Hihi ! Je suis Capychou, et voici mon bébé. Moi aussi j'adore les muffins… Je vais en chiper quelques-uns !"),
        ("licorne", "Si je vois une grande haie, je monte sur le tremplin arc-en-ciel et… BOULET DE CANON !"),
    ])


def level2():
    b = LB(170)
    b.ground(0, 30)
    b.put(3, 1, "@")
    b.items(6, 1, 4)
    b.put(12, 1, "L")
    b.items(15, 1, 4)
    b.put(22, 1, "C")
    b.pad(27, 39)
    b.items(31, 4, 6)
    b.ground(37, 64)                      # une grande vallée (cases 30 à 36) : Boulet de canon !
    b.put(42, 1, "B")
    b.put(46, 1, "K")
    b.items(49, 1, 4)
    b.ground(64, 66)
    b.ground(68, 92)                      # un petit trou (2 cases) : un petit saut suffit
    b.items(64, 2, 2)
    b.items(70, 1, 4)
    b.put(76, 1, "C")
    b.hill(80, 82, 1)
    b.items(80, 2, 2)
    b.pad(88, 104)
    b.items(93, 4, 8)
    b.ground(102, 130)                    # la deuxième grande vallée (cases 92 à 101)
    b.put(106, 1, "B")
    b.put(110, 1, "K")
    b.items(113, 1, 5)
    b.put(119, 1, "L")
    b.put(123, 1, "C")
    b.items(126, 1, 3)
    b.ground(132, 170)                    # un tout petit trou (2 cases)
    b.items(130, 2, 2)
    b.put(136, 1, "B")
    b.items(139, 1, 6)
    b.hill(147, 150, 1)
    b.items(147, 2, 3)
    b.put(160, 1, "F")
    return b.done(name="2  Les vallées vertes", intro=[
        ("licorne", "Des vallées ! Elles sont trop grandes pour un petit saut…"),
        ("capy", "Hihi ! Tu ne passeras pas ! Et j'ai déjà mangé deux muffins !"),
        ("licorne", "Avec le tremplin, je fais un BOULET DE CANON par-dessus la vallée !"),
    ])


def level3():
    b = LB(180)
    b.ground(0, 180)
    b.put(3, 1, "@")
    b.items(6, 1, 5)
    b.put(13, 1, "L")
    b.put(17, 1, "C")
    b.items(20, 2, 4)
    b.pad(26, 35)
    b.hedge(29, 2)
    b.items(29, 5, 4, step=1)
    b.put(37, 1, "B")
    b.put(40, 1, "K")
    b.items(43, 1, 4)
    b.put(49, 1, "L")
    b.put(53, 1, "L")
    b.items(56, 1, 4)
    b.put(62, 1, "C")
    b.pad(66, 77)
    b.hedge(69, 4)
    b.items(68, 5, 6, step=1)
    b.put(79, 1, "B")
    b.put(83, 1, "K")
    b.items(86, 1, 5)
    b.hill(93, 95, 1)
    b.items(93, 2, 2)
    b.put(98, 1, "C")
    b.items(101, 1, 4)
    b.put(106, 1, "L")
    b.pad(110, 121)
    b.hedge(113, 3)
    b.items(112, 5, 6, step=1)
    b.put(123, 1, "B")
    b.put(126, 1, "K")
    b.items(129, 1, 6)
    b.put(137, 1, "C")
    b.items(141, 2, 4)
    b.put(147, 1, "B")
    b.items(150, 1, 5)
    b.put(165, 1, "F")
    return b.done(name="3  Le chemin des arcs-en-ciel", intro=[
        ("licorne", "Le chemin des arcs-en-ciel ! Tout au bout, il y a le plus grand des arcs-en-ciel."),
        ("capy", "Hihi ! J'ai mis plein de haies sur le chemin. Bonne chance !"),
        ("licorne", "Même pas peur : je me ratatine… et BOULET DE CANON !"),
    ])


LEVELS = [level1, level2, level3]

# ----------------------------------------------------------------------------
# Les manches du Lance-nuage : des tours de caisses, des ballons, des muffins, et Capychou perché en haut.
# Chaque objet : (type, case x, case y depuis le sol) ; les caisses s'empilent.
# ----------------------------------------------------------------------------
ROUNDS = [
    dict(name="Les premières caisses", things=[("caisse", 14, 0), ("caisse", 14, 1), ("caisse", 15, 0), ("ballon", 17, 3),
                                               ("muffin", 12, 3), ("capy", 14, 2)]),
    dict(name="La double tour", things=[("caisse", 12, 0), ("caisse", 12, 1), ("caisse", 12, 2), ("caisse", 16, 0), ("caisse", 16, 1),
                                        ("ballon", 14, 4), ("muffin", 10, 2), ("muffin", 18, 3), ("capy", 16, 2)]),
    dict(name="Les ballons de la fête", things=[("ballon", 10, 3), ("ballon", 13, 4), ("ballon", 16, 3), ("ballon", 18, 5),
                                                ("caisse", 15, 0), ("caisse", 15, 1), ("muffin", 12, 1), ("capy", 15, 2)]),
    dict(name="Le château de caisses", things=[("caisse", 13, 0), ("caisse", 14, 0), ("caisse", 15, 0), ("caisse", 13, 1), ("caisse", 15, 1),
                                               ("caisse", 14, 2), ("muffin", 14, 1), ("ballon", 18, 4), ("capy", 14, 3)]),
    dict(name="La grande pyramide", things=[("caisse", 12, 0), ("caisse", 13, 0), ("caisse", 14, 0), ("caisse", 15, 0), ("caisse", 12.5, 1),
                                            ("caisse", 13.5, 1), ("caisse", 14.5, 1), ("caisse", 13, 2), ("caisse", 14, 2), ("ballon", 17, 5),
                                            ("muffin", 10, 3), ("muffin", 17, 2), ("capy", 13.5, 3)]),
]
