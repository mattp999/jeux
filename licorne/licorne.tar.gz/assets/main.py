import asyncio

import pygame          # (pygbag regarde les « import » de main.py pour savoir quoi charger)
import pygame.mixer

import licorne


async def main():
    game = licorne.Game()
    await game.run_async()


asyncio.run(main())
