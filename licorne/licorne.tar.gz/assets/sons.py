"""Sons fabriqués en code + remplacement possible par des fichiers du dossier sons/ (.mp3 prioritaire)."""
import math
import os
import random
from array import array

import pygame

import musique

RATE = 22050
SOUND_PRIORITY = (".mp3", ".ogg", ".wav")
# nom du fichier (sans extension) -> nom du son dans le jeu
CUSTOM = {
    "licorne_miam": "miam",          # Licorne mange un muffin
    "ratatine": "ratatine",          # Licorne se ratatine avant le Boulet de canon
    "boulet": "boulet",              # le Boulet de canon part !
    "capy_rit": "capy",              # Capy rigole (il a fait une bêtise) : c'est la voix de Capy, à chaque fois qu'il parle
    "licorne_parle": "licorne",      # la petite voix de Licorne, à chaque fois qu'elle parle
    "saut": "saut",                  # un petit saut
    "victoire": "victoire",          # fin d'un niveau ou d'une manche
    "etoile": "etoile",              # une étoile gagnée
}


def _to_sound(samples):
    ch = pygame.mixer.get_init()[2]
    vals = [int(max(-1.0, min(1.0, v)) * 30000) for v in samples]
    if ch == 2:
        st = [0] * (len(vals) * 2)
        st[0::2] = vals
        st[1::2] = vals
        vals = st
    return pygame.mixer.Sound(buffer=array("h", vals).tobytes())


def _lowpass(x, a):
    y = 0.0
    out = []
    for v in x:
        y += a * (v - y)
        out.append(y)
    return out


def tone(freqs, dur=0.12, vol=0.4, wave="sine", gap=0.0):
    out = []
    for f in freqs:
        n = int(RATE * dur)
        for i in range(n):
            t = i / n
            a = 2 * math.pi * f * i / RATE
            s = math.sin(a) if wave == "sine" else (1.0 if math.sin(a) > 0 else -1.0) * 0.5
            out.append(s * vol * (1 - t) ** 1.5)
        out.extend([0.0] * int(RATE * gap))
    return out


def sweep(f0, f1, dur, vol=0.4, wave="sine"):
    n = int(RATE * dur)
    out = []
    ph = 0.0
    for i in range(n):
        t = i / n
        ph += (f0 + (f1 - f0) * t) / RATE
        a = 2 * math.pi * ph
        s = math.sin(a) if wave == "sine" else (1.0 if math.sin(a) > 0 else -1.0) * 0.5
        out.append(s * vol * (1 - t))
    return out


def noise(dur, vol=0.4, lp=0.3, seed=1):
    rng = random.Random(seed)
    n = int(RATE * dur)
    return _lowpass([(rng.random() * 2 - 1) * vol * (1 - i / n) for i in range(n)], lp)


def blip(base, dur=0.09, wob=0.5, vol=0.42):
    n = int(RATE * dur)
    out = []
    ph = 0.0
    for i in range(n):
        t = i / n
        f = base * (1 + wob * math.sin(math.pi * t))
        ph += f / RATE
        a = 2 * math.pi * ph
        out.append((math.sin(a) + 0.45 * math.sin(2 * a)) * vol * math.sin(math.pi * t) ** 0.6)
    return out


def miam():
    """« Miam ! » : un petit croc tout doux, puis deux notes contentes, plutôt graves."""
    return [v * 0.4 for v in noise(0.05, 0.6, 0.3, 3)] + blip(300, 0.1, 0.25, 0.3) + blip(380, 0.14, 0.25, 0.3)


def ratatine():
    """Licorne se ratatine : « pouiiic » qui descend, comme un ressort qu'on écrase."""
    out = []
    n = int(RATE * 0.55)
    ph = 0.0
    for i in range(n):
        t = i / n
        f = 900 - 650 * t + 30 * math.sin(i / RATE * 2 * math.pi * 18)
        ph += f / RATE
        a = 2 * math.pi * ph
        out.append((math.sin(a) + 0.3 * math.sin(3 * a)) * 0.35 * (0.4 + 0.6 * (1 - t)))
    return out


def boulet():
    """Le Boulet de canon : « BOUM ! » puis le vent qui siffle « fiiiou »."""
    out = []
    n = int(RATE * 0.18)
    ph = 0.0
    for i in range(n):
        t = i / RATE
        ph += (60 + 160 * math.exp(-t * 30)) / RATE
        out.append(math.sin(2 * math.pi * ph) * 0.9 * math.exp(-t * 14))
    out = [o + v for o, v in zip(out, noise(0.18, 0.5, 0.3, 9) + [0.0] * n)]
    rng = random.Random(5)
    y = 0.0
    m = int(RATE * 0.7)
    for i in range(m):
        t = i / m
        y += (0.08 + 0.4 * (1 - t)) * ((rng.random() * 2 - 1) - y)
        out.append(y * 0.6 * math.sin(math.pi * t) + math.sin(2 * math.pi * (700 + 500 * t) * i / RATE) * 0.08 * (1 - t))
    return out


def hihi():
    """Capy rigole : « hi-hi-hi ! »."""
    out = []
    for f in (620, 700, 780):
        out += blip(f, 0.08, 0.2, 0.4)
        out += [0.0] * int(RATE * 0.04)
    return out


def licorne_voix(seed):
    """La petite voix de Licorne quand elle parle : quelques notes aiguës et chantantes (« hi-hin-hi ! »)."""
    rng = random.Random(seed)
    out = []
    for k in range(rng.randint(3, 4)):
        out += blip(rng.choice((760, 860, 960, 1080)), rng.uniform(0.06, 0.09), rng.uniform(0.15, 0.4), 0.3)
        out += [0.0] * int(RATE * 0.025)
    return out


class Sounds:
    def __init__(self, base_dir, progress=lambda k: None):
        self.ok = pygame.mixer.get_init() is not None
        self.s = {}
        self.music_snd = None
        self.music_file = None
        self.custom_files = {}
        if not self.ok:
            return
        self.dir = os.path.join(base_dir, "sons")
        ready = os.path.join(base_dir, "sons_prets")
        if os.path.isdir(ready):
            self._load_ready(ready)            # la version web : pas besoin de fabriquer les sons (trop long)
            progress(1.0)
            return
        steps = [
            ("miam", miam), ("ratatine", ratatine), ("boulet", boulet), ("capy", hihi),
            ("saut", lambda: sweep(300, 640, 0.13, 0.25)),
            ("pop", lambda: sweep(900, 1500, 0.08, 0.35)),
            ("caisse", lambda: [v * 1.2 for v in noise(0.12, 0.7, 0.2, 7)] + sweep(220, 120, 0.1, 0.25, "square")),
            ("boing", lambda: sweep(220, 660, 0.16, 0.4)),
            ("nuage", lambda: sweep(400, 1200, 0.3, 0.25)),
            ("etoile", lambda: tone([880, 1320, 1760], 0.08, 0.3)),
            ("drapeau", lambda: tone([523, 659, 784, 1046], 0.1, 0.33)),
            ("victoire", lambda: tone([587, 740, 880, 1175, 880, 1175], 0.13, 0.35, "square", 0.02)),
            ("menu", lambda: tone([700], 0.05, 0.25)),
            ("valide", lambda: tone([660, 990], 0.07, 0.3)),
        ]
        for k, (name, fn) in enumerate(steps):
            data = fn()
            self.s[name] = [_to_sound(data)]
            progress((k + 1) / (len(steps) + 3))
        self.s["licorne"] = [_to_sound(licorne_voix(k)) for k in range(4)]     # 4 petites voix, pour varier
        self._load_custom()
        # le volume de chaque son (1 = normal)
        for name, v in (("miam", 0.6), ("capy", 0.7)):
            for snd in self.s.get(name, []):
                snd.set_volume(v)
        if not self.music_file:
            self.music_snd = _to_sound(musique.render())
            self.music_snd.set_volume(0.35)
        progress(1.0)

    def _load_ready(self, folder):
        """Charge les sons déjà fabriqués (voir fabriquer_web.py) : nom.ogg, et licorne_0..3.ogg pour la voix."""
        for f in sorted(os.listdir(folder)):
            name, ext = os.path.splitext(f)
            if ext != ".ogg":
                continue
            try:
                snd = pygame.mixer.Sound(os.path.join(folder, f))
            except Exception:
                continue
            if name == "musique":
                self.music_snd = snd
                snd.set_volume(0.35)
            elif name.startswith("licorne_"):
                self.s.setdefault("licorne", []).append(snd)
            else:
                self.s[name] = [snd]
        for name, v in (("miam", 0.6), ("capy", 0.7)):
            for snd in self.s.get(name, []):
                snd.set_volume(v)

    def export(self, folder):
        """Écrit tous les sons du jeu en .ogg (pour la version web). Il faut le module soundfile."""
        import numpy
        import soundfile
        os.makedirs(folder, exist_ok=True)
        freq, size, chans = pygame.mixer.get_init()

        def write(path, snd):
            data = numpy.frombuffer(snd.get_raw(), dtype=numpy.int16).reshape(-1, chans).mean(axis=1) / 32768.0
            soundfile.write(path, data, freq, format="OGG", subtype="VORBIS")
        for name, lst in self.s.items():
            if name == "licorne":
                for k, snd in enumerate(lst):
                    write(os.path.join(folder, "licorne_%d.ogg" % k), snd)
            else:
                write(os.path.join(folder, name + ".ogg"), lst[0])
        mus = self.music_snd
        if self.music_file:
            mus = pygame.mixer.Sound(self.music_file)
        if mus:
            write(os.path.join(folder, "musique.ogg"), mus)

    def _load_custom(self):
        if not os.path.isdir(self.dir):
            return
        found = {}
        for f in os.listdir(self.dir):
            path = os.path.join(self.dir, f)
            name, ext = os.path.splitext(f.lower())
            if ext in SOUND_PRIORITY and os.path.isfile(path):
                found.setdefault(name, {})[ext] = path
        for name in sorted(found):
            paths = [found[name][e] for e in SOUND_PRIORITY if e in found[name]]
            if name == "musique":
                for path in paths:
                    try:
                        pygame.mixer.music.load(path)
                        self.music_file = path
                        break
                    except Exception:
                        continue
                continue
            for path in paths:
                try:
                    snd = pygame.mixer.Sound(path)
                except Exception:
                    continue
                self.custom_files[name] = os.path.basename(path)
                if name in CUSTOM:
                    self.s[CUSTOM[name]] = [snd]
                break
        lines = ["Sons personnels trouvés au dernier démarrage du jeu", "(le .mp3 passe avant le .ogg, qui passe avant le .wav)", ""]
        if self.music_file:
            lines.append("musique  ->  " + os.path.basename(self.music_file))
        for name, f in sorted(self.custom_files.items()):
            lines.append("%s  ->  %s%s" % (name, f, "" if name in CUSTOM else "   (nom inconnu du jeu : il n'est pas utilisé)"))
        if len(lines) == 3:
            lines.append("Aucun son personnel : le jeu utilise ses propres sons.")
        try:
            with open(os.path.join(self.dir, "sons_utilises.txt"), "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
        except Exception:
            pass

    def play(self, name, vol=1.0):
        if not self.ok or name not in self.s:
            return None
        ch = random.choice(self.s[name]).play()
        if ch:
            ch.set_volume(vol)
        return ch

    def start_music(self):
        if not self.ok:
            return
        if self.music_file:
            try:
                pygame.mixer.music.load(self.music_file)
                pygame.mixer.music.set_volume(0.4)
                pygame.mixer.music.play(-1)
                return
            except Exception:
                self.music_file = None
                self.music_snd = _to_sound(musique.render())
                self.music_snd.set_volume(0.35)
        if self.music_snd:
            if not hasattr(self, "_mus_ch"):
                self._mus_ch = pygame.mixer.Channel(0)
            if not self._mus_ch.get_busy():
                self._mus_ch.play(self.music_snd, loops=-1)
