"""LICORNE — deux jeux avec Licorne, la licorne qui adore les muffins à l'herbe aux pépites de chocolat.

1. L'aventure : Licorne trotte dans la prairie (petits sauts), mange les muffins, et devant les grandes haies
   ou les grandes vallées, elle se ratatine sur le tremplin arc-en-ciel… BOULET DE CANON !
   Capychou le capybara (avec sa capuche blanche et son bébé dans les bras) fait des petites bêtises (il chipe des muffins). On ne perd jamais.
2. Le lance-nuage : Licorne se ratatine dans le lance-nuage et part en Boulet de canon sur des tours de caisses,
   des ballons, des muffins… et Capychou. 5 tirs par manche ; si une manche rate, la suivante est plus facile.

Clavier : flèches + ESPACE (sauter / lancer) + Ctrl (Boulet de canon n'importe où, quand la jauge est pleine).
Manette : croix + A (sauter / lancer) + B (Boulet de canon).  Échap / Start : pause.  F11 : plein écran.
"""
import asyncio
import json
import math
import os
import random

import pygame

import images as I
from commun import Txt, Device, Touch, clamp, base_dir, panel, syllables, WEB
from niveaux import LEVELS, ROUNDS
from sons import Sounds

W, H = 1280, 720
T = 64
G = 2400
JUMP = 700            # petits sauts : un peu plus d'une case
SPEED = 260
SKY = 2
LW, LH = 184, 141     # la taille de Licorne à l'écran (bien plus grande que Capychou)
BOULET_VX = 560       # la vitesse du Boulet de canon (on la dirige avec gauche / droite)
TITLE = "Licorne"
NAMES = {"licorne": "Licorne", "capy": "Capychou"}
COLS = {"licorne": (190, 120, 230), "capy": (200, 130, 70)}
EAT = ["Miam !", "Trop bon !", "Miam miam !", "Un muffin à l'herbe !", "Délicieux !"]
CAPY_HOP = ["Hop ! On se revoit plus loin !", "Hihi ! Attrape-moi !", "Hop hop hop !", "Je t'attends plus loin !"]
# un peu plus difficile à chaque niveau : Capychou lance son jet plus souvent et de plus loin
CAPY_JET_CD = [(3.5, 5.5), (3.0, 4.5), (2.4, 3.6)]
CAPY_JET_RANGE = [6.5, 7.5, 8.5]
CAPY_JET = ["Pschhht ! Hihi !", "Attention, ça mouille !", "Un petit jet de ma gourde !", "Hihi ! Jus de feuilles !"]
# ce que Licorne dit à chaque fois que le jet vert de Capychou la touche (ça sent mauvais !)
LICORNE_BEURK = ["Pouah ! Ça sent vraiment pas bon, ça !", "Beurk ! Ça pue, ce jus de feuilles !",
                 "Pouah ! Ça sent le vieux chou !", "Beurk ! Ça sent vraiment pas bon !"]
CAPY_HIT = ["Oh ! Pardon, pardon ! Tiens, reprends tes muffins !", "Waouh ! Un Boulet de canon ! Je te rends tout !"]


def btn(dev, which):
    """Le nom du bouton à afficher, selon la manette, le clavier ou l'écran tactile."""
    if which == "b":
        # (dans le navigateur, Ctrl + une touche peut fermer l'onglet : on dit X)
        return {"kb": "X" if WEB else "Ctrl", "kb2": "G", "touch": "Boulet"}.get(dev.kind, "B")
    return {"kb": "ESPACE", "kb2": "F", "touch": "Saut"}.get(dev.kind, "A")


class Spark:
    def __init__(self, x, y, color, sp=220):
        a = random.uniform(0, math.tau)
        v = random.uniform(60, sp)
        self.x, self.y = x, y
        self.vx, self.vy = math.cos(a) * v, math.sin(a) * v - 60
        self.t = 0.0
        self.life = random.uniform(0.4, 0.8)
        self.color = color

    def update(self, dt):
        self.t += dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += 500 * dt
        return self.t < self.life


class Float:
    def __init__(self, x, y, text, color=(255, 240, 120)):
        self.x, self.y, self.text, self.color, self.t = x, y, text, color, 0.0

    def update(self, dt):
        self.t += dt
        self.y -= 50 * dt
        return self.t < 1.0


def toute_verte(img):
    """Licorne toute verte de dégoût (le liquide vert de la gourde de Capychou)."""
    img = pygame.transform.grayscale(img)            # on garde les ombres…
    img.fill((150, 255, 90, 255), special_flags=pygame.BLEND_RGBA_MULT)   # … mais tout devient vert pomme
    img.fill((40, 70, 0, 0), special_flags=pygame.BLEND_RGBA_ADD)
    return img


def vert_qui_part(img, k):
    """Licorne encore un peu verte : k = 1 toute verte, k = 0 plus du tout."""
    out = img.copy()
    v = toute_verte(img)
    v.set_alpha(int(255 * max(0.0, min(1.0, k))))
    out.blit(v, (0, 0))
    return out


def draw_jet(s, x, y):
    """Une goutte du jet vert de Capychou."""
    pygame.draw.circle(s, (90, 150, 60), (int(x), int(y)), 12)
    pygame.draw.circle(s, (160, 215, 100), (int(x), int(y)), 9)
    pygame.draw.circle(s, (220, 250, 190), (int(x - 3), int(y - 3)), 3)


def speech(text, dur=1.8):
    return {"text": text, "t": dur, "marks": syllables(text) or [len(text)], "k": 0, "timer": 0.0}


def speech_step(sp, dt):
    if not sp:
        return None
    sp["t"] -= dt
    if sp["k"] < len(sp["marks"]):
        sp["timer"] -= dt
        if sp["timer"] <= 0:
            sp["k"] += 1
            sp["timer"] = 0.09
    return sp if sp["t"] > 0 else None


def speech_text(sp):
    k = sp["k"]
    return sp["text"] if k >= len(sp["marks"]) else sp["text"][:sp["marks"][k - 1]] if k > 0 else ""


# ============================================================================
# Jeu 1 : l'aventure
# ============================================================================
class Capy:
    w, h = 72, 100

    def __init__(self, x, y):
        self.x, self.y = x, y          # centre, pieds
        self.home = x
        self.dir = -1
        self.t = random.uniform(0, 3)
        self.cd = 0.0
        self.dizzy = 0.0
        self.fly = None
        self.speech = None
        self.shoot_cd = random.uniform(2.0, 4.0)
        self.aim = 0.0                 # il lève sa gourde, juste avant le jet
        self.leap = None               # il saute très loin pour revenir plus loin dans le niveau
        self.spot = 0                  # à quel endroit du niveau il est
        self.final = False             # tout au bout : il attend Licorne avec le muffin géant
        self.gone = False

    def rect(self):
        return pygame.Rect(int(self.x - self.w / 2), int(self.y - self.h), self.w, self.h)

    def jump_to(self, x1, y1, final=False):
        """Un grand saut (on le voit passer au-dessus de Licorne) jusqu'à un endroit plus loin."""
        d = abs(x1 - self.x)
        self.leap = {"t": 0.0, "x0": self.x, "y0": self.y, "x1": x1, "y1": y1, "final": final,
                     "dur": clamp(d / 650, 1.1, 2.4), "hgt": min(460, 240 + d * 0.12)}
        self.dir = 1 if x1 > self.x else -1
        self.aim = 0.0

    def update(self, dt):
        self.t += dt
        self.cd = max(0.0, self.cd - dt)
        self.speech = speech_step(self.speech, dt)
        if self.leap:
            lp = self.leap
            lp["t"] += dt
            k = min(1.0, lp["t"] / lp["dur"])
            kx = k ** 1.6                  # il monte d'abord bien haut (au-dessus de Licorne), puis il file plus loin
            self.x = lp["x0"] + (lp["x1"] - lp["x0"]) * kx
            self.y = lp["y0"] + (lp["y1"] - lp["y0"]) * k - math.sin(math.pi * k) * lp["hgt"]
            if k >= 1:
                self.leap = None
                self.home = self.x
                self.dir = -1
                self.final = lp["final"]
                self.shoot_cd = random.uniform(1.5, 2.5)
            return
        if self.final:
            return                     # il attend Licorne au bout du chemin
        if self.fly:
            f = self.fly
            f["t"] += dt
            k = min(1.0, f["t"] / 0.9)
            self.x = f["x0"] + f["dx"] * k
            self.y = f["y0"] - math.sin(math.pi * k) * 160
            if k >= 1:
                self.fly = None
                self.dizzy = 3.0
            return
        if self.dizzy > 0:
            self.dizzy -= dt
            return
        if self.aim > 0:
            return                     # il vise : il ne bouge plus
        self.x += self.dir * 50 * dt
        if abs(self.x - self.home) > 2.5 * T:
            self.dir *= -1
            self.x = clamp(self.x, self.home - 2.5 * T, self.home + 2.5 * T)


class Adventure:
    def __init__(self, game, idx):
        self.game = game
        self.idx = idx
        lv = LEVELS[idx]()
        self.data = lv
        self.w, self.h = lv["w"], lv["h"] + SKY
        self.pw, self.ph = self.w * T, self.h * T
        self.grid = [[" "] * self.w for _ in range(SKY)] + [list(r) for r in lv["grid"]]
        self.ground_y = (self.h - 2) * T
        self.var = [[random.randrange(3) for _ in range(self.w)] for _ in range(self.h)]
        self.muffins, self.crates, self.capys, self.flags, self.pads = [], [], [], [], []
        self.capy_spots = []              # les endroits où Capychou revient (il saute de l'un à l'autre)
        self.finish = None
        spawn = (3 * T, self.ground_y)
        for cy, row in enumerate(self.grid):
            for cx, ch in enumerate(row):
                px, py = cx * T + T / 2, cy * T + T / 2
                if ch == "@":
                    spawn = (px, (cy + 1) * T)
                elif ch == "m":
                    self.muffins.append({"x": px, "y": py, "alive": True, "ph": random.uniform(0, 6), "vy": None})
                elif ch == "B":
                    self.crates.append({"x": px, "y": (cy + 1) * T, "alive": True})
                elif ch == "C":
                    self.capy_spots.append((px, (cy + 1) * T))
                elif ch == "K":
                    self.flags.append({"x": px, "y": (cy + 1) * T, "on": False})
                elif ch == "P":
                    self.pads.append({"x": px, "y": (cy + 1) * T, "to": lv["pads"][cx]})
                elif ch == "F":
                    self.finish = (px, (cy + 1) * T)
                if ch in "@mBCKPF":
                    row[cx] = " "
        self.capy_spots.sort()
        if self.capy_spots:
            self.capys.append(Capy(*self.capy_spots[0]))          # un seul Capychou, qui revient plus loin
        self.last = idx + 1 >= len(LEVELS)
        self.gift = None                  # tout au bout de l'aventure : Capychou offre le muffin géant
        self.intro_t = 3.0                # le nom du niveau, en grand, au début
        self.total = len(self.muffins) + 3 * len(self.crates)
        self.eaten = 0
        self.score = 0
        self.x, self.y = spawn            # Licorne : centre, pieds
        self.vx = self.vy = 0.0
        self.on_ground = True
        self.facing = 1
        self.anim = 0.0
        self.safe = spawn
        self.checkpoint = spawn
        self.boulet = None                # le Boulet de canon en cours
        self.cloud = None                 # le petit nuage qui la ramène quand elle tombe
        self.bump_t = 0.0
        self.wet = 0.0                    # mouillée par le jet de Capychou (elle ne peut pas être re-mouillée tout de suite)
        self.drop_t = 0.0                 # elle est toute verte de dégoût… et lâche ses muffins quand ce temps arrive à 0
        self.jets = []
        self.debris = []                  # ce que le Boulet de canon a renversé (troncs, haies), qui s'envole
        self.speech = None
        self.sparks, self.floats = [], []
        self.t = 0.0
        self.done = False
        self.done_t = 0.0
        self.banner = 0.0
        self.cam_x = clamp(self.x - W / 3, 0, self.pw - W)
        self.cam_y = clamp(self.ground_y - H * 0.72, 0, self.ph - H)
        self.bg = game.bgs[idx % len(game.bgs)]

    # --- tuiles
    def tile(self, cx, cy):
        if cx < 0 or cx >= self.w:
            return "#"
        if cy < 0 or cy >= self.h:
            return " "
        return self.grid[cy][cx]

    def solid(self, cx, cy):
        return self.tile(cx, cy) in "#LH"

    def surface_at(self, x):
        """Le haut du sol à cette colonne (ou None s'il y a un trou)."""
        c = int(x // T)
        for r in range(self.h):
            if self.solid(c, r):
                return r * T
        return None

    def say(self, text, dur=1.8):
        self.speech = speech(text, dur)
        self.game.snd.play("licorne", 0.8)                # la petite voix de Licorne

    # --- Licorne bouge (petits sauts)
    def move(self, dt):
        hw, hh = 34, 70
        self.x += self.vx * dt
        top, bot = int((self.y - hh) // T), int((self.y - 1) // T)
        if self.vx > 0:
            c = int((self.x + hw) // T)
            if any(self.solid(c, r) for r in range(top, bot + 1)):
                self.x = c * T - hw - 0.01
                self.vx = 0
        elif self.vx < 0:
            c = int((self.x - hw) // T)
            if any(self.solid(c, r) for r in range(top, bot + 1)):
                self.x = (c + 1) * T + hw + 0.01
                self.vx = 0
        self.y += self.vy * dt
        self.on_ground = False
        l, r = int((self.x - hw + 4) // T), int((self.x + hw - 4) // T)
        if self.vy >= 0:
            row = int(self.y // T)
            if any(self.solid(c, row) for c in range(l, r + 1)):
                self.y = row * T
                self.vy = 0
                self.on_ground = True
        else:
            row = int((self.y - hh) // T)
            if any(self.solid(c, row) for c in range(l, r + 1)):
                self.y = (row + 1) * T + hh
                self.vy = 0

    def charge_dt(self, dt, b):
        """Le Boulet de canon vers Capychou : elle fonce tout droit (sans tomber), et renverse tout
        sur son passage : Capychou, les caisses, les troncs et même les haies."""
        g = self.game
        b["dash"] += dt
        hw, hh = 34, 70
        top, bot = int((self.y - hh) // T), int((self.y - 1) // T)
        c = int((self.x + self.facing * (hw + 10)) // T)
        stop = False
        for r in range(top, bot + 1):
            t = self.tile(c, r)
            if t in "LH":
                self.grid[r][c] = " "              # renversé !
                self.score += 10
                self.debris.append({"x": c * T + T / 2, "y": r * T + T / 2, "vx": self.facing * random.uniform(250, 420),
                                    "vy": random.uniform(-700, -500), "rot": 0.0, "k": "log" if t == "L" else "hedge"})
                g.snd.play("caisse")
                for _ in range(10):
                    self.sparks.append(Spark(c * T + T / 2, r * T + T / 2, (210, 160, 90) if t == "L" else (90, 190, 80)))
            elif t == "#":
                stop = True                        # le sol (une colline) : là, elle s'arrête
        if not stop:
            self.x += self.vx * dt
        self.x = clamp(self.x, 40, self.pw - 40)
        for _ in range(4):
            self.sparks.append(Spark(self.x - self.facing * 50, self.y - 40 + random.uniform(-20, 20), random.choice(I.ARC), 60))
        self.smash()
        if stop or b["dash"] > 0.75 or self.x <= 40 or self.x >= self.pw - 40:
            self.boulet = None                     # fini : elle retombe normalement
            self.vx *= 0.3
            self.vy = 0
            g.snd.play("boing")
            for _ in range(20):
                self.sparks.append(Spark(self.x, self.y, random.choice(I.ARC)))

    def capy_moves(self):
        """Quand Licorne a dépassé Capychou, il fait un grand saut pour revenir plus loin dans le niveau.
        Au dernier niveau, son dernier saut l'amène tout au bout, où il attend Licorne avec le muffin géant."""
        g = self.game
        for cp in self.capys:
            if cp.leap or cp.fly or cp.final or cp.dizzy > 0 or cp.aim > 0 or self.done:
                continue
            if self.x - cp.x > 3 * T:
                cp.spot += 1
                if cp.spot < len(self.capy_spots):
                    cp.jump_to(*self.capy_spots[cp.spot])
                elif self.last and self.finish:
                    cp.jump_to(self.finish[0] + 3.5 * T, self.finish[1], final=True)
                else:
                    cp.jump_to(self.pw + 6 * T, self.ground_y)       # il file tout au bout, jusqu'au prochain niveau
                    cp.gone = True
                cp.speech = speech(random.choice(CAPY_HOP), 1.4)
                g.snd.play("capy")
        self.capys = [cp for cp in self.capys if not (cp.gone and not cp.leap)]

    def update_gift(self, dt):
        """Tout au bout de l'aventure : Capychou vient offrir le muffin géant à Licorne."""
        g = self.game
        gf = self.gift
        gf["t"] += dt
        cp = gf["capy"]
        if cp.leap:
            return
        if gf["phase"] == "walk":
            tx = self.x + 3.6 * T
            cp.dir = -1
            if cp.x > tx:
                cp.x = max(tx, cp.x - 150 * dt)
            else:
                gf["phase"], gf["t"] = "give", 0.0
                self.speech = None                         # on laisse parler Capychou
                cp.speech = speech("Tiens Licorne ! Un muffin géant, rien que pour toi. Pardon pour mes bêtises !", 3.4)
                g.snd.play("capy")
        elif gf["phase"] == "give" and gf["t"] > 3.2:
            gf["phase"], gf["t"] = "fly", 0.0
            g.snd.play("boing")
        elif gf["phase"] == "fly" and gf["t"] > 0.8:
            gf["phase"], gf["t"] = "eat", 0.0
            self.say("Miam ! Merci Capychou ! Tu es mon ami !", 2.6)
            self.score += 100
            self.floats.append(Float(self.x + 60, self.y - 160, "+100", (255, 240, 120)))
            g.snd.play("miam")
        elif gf["phase"] == "eat":
            if random.random() < 0.5:
                self.sparks.append(Spark(self.x + 80, self.y - 70, random.choice(((140, 220, 110), (255, 170, 210), (120, 80, 50)))))
            if int(gf["t"] * 4) != int((gf["t"] - dt) * 4):
                g.snd.play("miam", 0.6)
            if gf["t"] > 2.6:
                gf["phase"] = "end"
                for _ in range(30):
                    self.sparks.append(Spark(self.x, self.y - 80, random.choice(I.ARC)))

    def scene_over(self):
        """Le niveau est fini et on peut passer à l'écran des étoiles."""
        if not self.done:
            return False
        if self.gift:
            return self.gift["phase"] == "end" and self.done_t > 1.0
        return self.done_t > 2.5

    def capy_ahead(self):
        """Capychou devant Licorne (à moins de 9 cases), pour lui foncer dessus en Boulet de canon."""
        best = None
        for cp in self.capys:
            d = (cp.x - self.x) * self.facing
            if 40 < d < 9 * T and not cp.fly and not cp.leap and not cp.final and abs(cp.y - self.y) < 2 * T and (best is None or d < best[0]):
                best = (d, cp)
        return best[1] if best else None

    def pad_here(self):
        """Le tremplin compte du tremplin jusqu'à la haie (ou au bord de la vallée) : on ne peut pas le rater."""
        for p in self.pads:
            if p["x"] - 46 <= self.x <= p["x"] + 2.7 * T and abs(p["y"] - self.y) < 8 and self.on_ground:
                return p
        return None

    def start_boulet(self, low=False):
        """Boulet de canon : elle se ratatine (0,6 s), « BOULET DE CANON ! », puis elle part en flèche.
        En l'air, on la dirige avec gauche / droite, comme quand elle marche.
        low : trajectoire plus basse (pour foncer sur Capychou)."""
        self.boulet = {"t": 0.0, "low": low}
        self.vx = self.vy = 0
        self.banner = 1.8
        self.game.snd.play("ratatine")

    def update(self, dt):
        g = self.game
        dev = g.player
        self.t += dt
        self.anim += dt
        self.banner = max(0.0, self.banner - dt)
        self.speech = speech_step(self.speech, dt)
        self.bump_t = max(0.0, self.bump_t - dt)
        self.intro_t = max(0.0, self.intro_t - dt)
        for c in self.capys:
            c.update(dt)
        self.capy_moves()
        if self.done:
            self.done_t += dt
            if self.gift:
                self.update_gift(dt)
        elif self.cloud:
            # le petit nuage la ramène sur le dernier endroit sûr
            cl = self.cloud
            cl["t"] += dt
            k = min(1.0, cl["t"] / 1.2)
            self.x = cl["x0"] + (self.safe[0] - cl["x0"]) * k
            self.y = cl["y0"] + (self.safe[1] - cl["y0"]) * k - math.sin(math.pi * k) * 120
            if k >= 1:
                self.cloud = None
                self.vx = self.vy = 0
        elif self.boulet and self.boulet.get("dash") is not None:
            self.boulet["t"] += dt
            self.charge_dt(dt, self.boulet)                 # vers Capychou : tout droit !
        elif self.boulet:
            b = self.boulet
            b["t"] += dt
            ax = dev.axis()
            if ax:
                self.facing = ax
            if b["t"] < 0.6:
                self.vx = self.vy = 0                       # elle se ratatine (on peut encore choisir le côté)
            else:
                if not b.get("go"):
                    b["go"] = True
                    g.snd.play("boulet")
                    self.vx = self.facing * BOULET_VX
                    self.vy = -950
                    if b["low"]:
                        b["dash"] = 0.0           # vers Capychou : tout droit, à toute vitesse !
                        self.vx = self.facing * 950
                        self.vy = 0
                # en l'air, on la dirige comme quand elle marche
                if ax:
                    self.vx += (ax * BOULET_VX - self.vx) * min(1, dt * 6)
                self.vy = min(self.vy + 1100 * dt, 1000)
                self.move(dt)
                self.x = clamp(self.x, 40, self.pw - 40)
                for _ in range(3):
                    self.sparks.append(Spark(self.x - self.facing * 40, self.y - 60, random.choice(I.ARC), 80))
                self.smash()
                if self.on_ground and b["t"] > 0.7:
                    self.boulet = None
                    self.vx *= 0.3
                    g.snd.play("boing")
                    for _ in range(20):
                        self.sparks.append(Spark(self.x, self.y, random.choice(I.ARC)))
                elif self.y > self.ph + 40:
                    self.boulet = None
                    self.cloud = {"t": 0.0, "x0": self.x, "y0": self.ph}
                    g.snd.play("nuage")
                    self.say("Oups ! Merci petit nuage !", 1.6)
        else:
            ax = dev.axis()
            target = ax * SPEED
            acc = (1800 if self.on_ground else 1200) * dt
            self.vx = min(target, self.vx + acc) if self.vx < target else max(target, self.vx - acc)
            if ax:
                self.facing = ax
            if dev.pressed("f") and self.on_ground:
                self.vy = -JUMP                               # un petit saut normal
                g.snd.play("saut", 0.7)
            if dev.pressed("b") and not self.boulet:
                # le bouton du Boulet de canon, n'importe quand (pour les grands obstacles ou pour Capychou)
                self.start_boulet(low=self.capy_ahead() is not None and self.pad_here() is None)
            if not self.boulet:
                self.vy = min(self.vy + G * dt, 1000)
                self.move(dt)
                self.x = clamp(self.x, 40, self.pw - 40)
                if self.on_ground:
                    c0, c1 = int((self.x - 30) // T), int((self.x + 30) // T)
                    row = int(self.y // T)
                    if all(self.tile(c, row) == "#" for c in range(c0, c1 + 1)):
                        self.safe = (self.x, self.y)
                if self.y > self.ph + 40:
                    # elle est tombée : un petit nuage vient la chercher (on ne perd rien)
                    self.cloud = {"t": 0.0, "x0": self.x, "y0": self.ph}
                    g.snd.play("nuage")
                    self.say(random.choice(("Oups ! Merci petit nuage !", "Hop, un nuage !")), 1.6)
        self.collect()
        self.capy_mischief(dt)
        # drapeaux
        for f in self.flags:
            if not f["on"] and abs(f["x"] - self.x) < 40:
                f["on"] = True
                self.checkpoint = (f["x"], f["y"])
                g.snd.play("drapeau")
                for _ in range(14):
                    self.sparks.append(Spark(f["x"], f["y"] - 100, random.choice(I.ARC)))
        if self.finish and not self.done and self.x >= self.finish[0] - 20:
            self.done = True
            g.snd.play("victoire")
            self.say("Youpi ! Le grand arc-en-ciel !", 2.5)
            self.vx = 0
            if self.last:
                cp = next((c for c in self.capys if c.final or (c.leap and c.leap["final"])), None)
                if cp is None:                                     # il arrive tout de suite au bout du chemin
                    cp = self.capys[0] if self.capys else Capy(self.finish[0] + 3.5 * T, self.finish[1])
                    if cp not in self.capys:
                        self.capys.append(cp)
                    cp.gone = False
                    cp.fly = None
                    cp.dizzy = 0.0
                    cp.jump_to(self.finish[0] + 3.5 * T, self.finish[1], final=True)
                self.gift = {"t": 0.0, "phase": "walk", "capy": cp}
        # caméra
        tx = clamp(self.x - W * 0.38, 0, self.pw - W)
        ty = clamp(self.y - H * 0.66, 0, self.ph - H)
        self.cam_x += (tx - self.cam_x) * min(1, dt * 6)
        self.cam_y += (ty - self.cam_y) * min(1, dt * 4)
        self.sparks = [s for s in self.sparks if s.update(dt)]
        self.floats = [f for f in self.floats if f.update(dt)]
        for d in self.debris:
            d["vy"] += 1400 * dt
            d["x"] += d["vx"] * dt
            d["y"] += d["vy"] * dt
            d["rot"] += d["vx"] * dt * 1.5
        self.debris = [d for d in self.debris if d["y"] < self.ph + 100]
        for m in self.muffins:
            if m["alive"] and m.get("pull"):                # aspiré par Licorne en Boulet de canon
                dx, dy = self.x - m["x"], (self.y - 70) - m["y"]
                d = math.hypot(dx, dy)
                if d < 60:
                    self.eat(m)
                else:
                    k = min(1, 1500 * dt / d)
                    m["x"] += dx * k
                    m["y"] += dy * k
                continue
            if m["vy"] is not None:                         # un muffin que Capy a fait tomber
                m["vy"] += 1400 * dt
                m["y"] += m["vy"] * dt
                m["x"] += m.get("vx", 0) * dt
                s = self.surface_at(m["x"])
                if s is not None and m["y"] >= s - 30:
                    m["y"] = s - 30
                    m["vy"] = None
                elif m["y"] > self.ph:
                    m["alive"] = False            # tombé dans une vallée
                    self.total -= 1

    def eat(self, m):
        g = self.game
        m["alive"] = False
        self.eaten += 1
        self.score += 10
        self.floats.append(Float(m["x"], m["y"] - 20, "+10"))
        g.snd.play("miam")
        if random.random() < 0.15:
            self.say(random.choice(EAT), 1.2)
        for _ in range(8):
            self.sparks.append(Spark(m["x"], m["y"], (140, 220, 110)))

    def collect(self):
        r = pygame.Rect(int(self.x - 40), int(self.y - 84), 80, 84)
        for m in self.muffins:
            if m["alive"] and m["vy"] is None and r.collidepoint(m["x"], m["y"]) and not (self.wet > 1.0 and m.get("ph") == 0):
                self.eat(m)
            elif m["alive"] and self.boulet and math.hypot(m["x"] - self.x, m["y"] - (self.y - 70)) < 280:
                m["pull"] = True                  # en Boulet de canon, les muffins autour d'elle volent jusqu'à elle

    def smash(self):
        """Pendant le Boulet de canon : les caisses de muffins se cassent, Capy s'envole."""
        g = self.game
        r = pygame.Rect(int(self.x - 70), int(self.y - 130), 140, 144)
        for c in self.crates:
            if c["alive"] and r.colliderect(pygame.Rect(c["x"] - 32, c["y"] - 64, 64, 64)):
                c["alive"] = False
                g.snd.play("caisse")
                self.score += 20
                for k in range(3):
                    self.muffins.append({"x": c["x"] + (k - 1) * 30, "y": c["y"] - 60, "alive": True, "ph": 0, "vy": -400 - k * 60, "vx": (k - 1) * 90})
                for _ in range(16):
                    self.sparks.append(Spark(c["x"], c["y"] - 30, (210, 160, 90)))
        for cp in self.capys:
            if not cp.fly and not cp.leap and not cp.final and r.colliderect(cp.rect()):
                cp.fly = {"t": 0.0, "x0": cp.x, "y0": cp.y, "dx": 140 if self.x < cp.x else -140}
                g.snd.play("capy")
                self.score += 30
                self.total += 3
                for k in range(3):
                    self.muffins.append({"x": cp.x, "y": cp.y - 80, "alive": True, "ph": 0, "vy": -500, "vx": (k - 1) * 120})

    def capy_mischief(self, dt):
        """Capychou lance un jet de sa gourde (un liquide verdâtre) sur Licorne. S'il la touche, elle lâche
        2 muffins, qui sautent autour d'elle (on peut les rattraper). En Boulet de canon, rien ne la touche."""
        g = self.game
        self.wet = max(0.0, self.wet - dt)
        if self.drop_t > 0:
            self.drop_t -= dt
            if self.drop_t <= 0:
                self.drop_muffins()
        cd = CAPY_JET_CD[self.idx % len(CAPY_JET_CD)]
        rng = CAPY_JET_RANGE[self.idx % len(CAPY_JET_RANGE)]
        for cp in self.capys:
            if cp.fly or cp.leap or cp.final or cp.dizzy > 0 or self.done:
                cp.aim = 0.0
                continue
            dx = self.x - cp.x
            if cp.aim > 0:
                cp.aim -= dt
                cp.dir = 1 if dx > 0 else -1
                if cp.aim <= 0:
                    # Pschhht ! le jet part en arc vers Licorne
                    vx = clamp(dx / 0.9, -420, 420)
                    self.jets.append({"x": cp.x + cp.dir * 26, "y": cp.y - 66, "vx": vx, "vy": -420.0, "t": 0.0})
                    g.snd.play("pop")
                    cp.shoot_cd = random.uniform(*cd)
                continue
            cp.shoot_cd -= dt
            if cp.shoot_cd <= 0 and abs(dx) < rng * T and abs(cp.y - self.y) < 2 * T and not self.boulet and not self.cloud:
                cp.aim = 0.7
                cp.dir = 1 if dx > 0 else -1
                cp.speech = speech(random.choice(CAPY_JET), 1.6)
                g.snd.play("capy")
        r = pygame.Rect(int(self.x - 50), int(self.y - 80), 100, 80)
        for j in self.jets:
            j["t"] += dt
            j["vy"] += 1000 * dt
            j["x"] += j["vx"] * dt
            j["y"] += j["vy"] * dt
            if random.random() < 0.6:
                self.sparks.append(Spark(j["x"], j["y"], (150, 200, 90), 40))
            if not self.boulet and self.wet <= 0 and r.collidepoint(j["x"], j["y"]):
                j["done"] = True
                self.splash(j)
            else:
                ground = self.surface_at(j["x"])
                if (ground is not None and j["y"] >= ground) or j["y"] > self.ph or j["t"] > 3:
                    j["done"] = True
                    for _ in range(10):
                        self.sparks.append(Spark(j["x"], j["y"] - 4, (140, 190, 80), 120))
        self.jets = [j for j in self.jets if not j.get("done")]

    def splash(self, j):
        """Le jet touche Licorne : elle devient toute verte de dégoût… puis elle lâche 2 muffins (qu'on peut rattraper)."""
        g = self.game
        self.wet = 2.4
        self.drop_t = 0.8
        g.snd.play("nuage")
        for _ in range(22):
            self.sparks.append(Spark(self.x, self.y - 50, random.choice(((140, 200, 80), (170, 220, 110), (110, 170, 70)))))
        self.say(random.choice(LICORNE_BEURK), 2.2)

    def drop_muffins(self):
        n = min(2, self.eaten)
        if n:
            self.eaten -= n
            self.score = max(0, self.score - 10 * n)
            self.floats.append(Float(self.x, self.y - 120, "-%d muffin%s" % (n, "s" if n > 1 else ""), (255, 200, 200)))
            for k in range(n):
                side = -1 if k == 0 else 1
                self.muffins.append({"x": self.x + side * 20, "y": self.y - 80, "alive": True, "ph": 0, "vy": -560, "vx": side * 190})
            self.game.snd.play("pop")

    # --- dessin
    def draw(self, s):
        g = self.game
        cx, cy = int(self.cam_x), int(self.cam_y)
        sky, far, mid, near = self.bg
        bi = self.idx % len(g.bgs)
        if WEB:
            # dans le navigateur : une seule image pour le ciel, les collines et les arbres (beaucoup plus rapide)
            ox = -int(cx * 0.3) % W
            s.blit(g.flats[bi], (ox - W, -int(cy * 0.2)))
            s.blit(g.flats[bi], (ox, -int(cy * 0.2)))
        else:
            s.blit(sky, (0, 0))
            for layer, f in ((far, 0.1), (mid, 0.3)):
                ox = -int(cx * f) % W
                s.blit(layer, (ox - W, -int(cy * 0.2)))
                s.blit(layer, (ox, -int(cy * 0.2)))
        tiles = g.tiles
        c0, c1 = max(0, cx // T), min(self.w - 1, (cx + W) // T + 1)
        r0, r1 = max(0, cy // T), min(self.h - 1, (cy + H) // T + 1)
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                t = self.grid[r][c]
                X, Y = c * T - cx, r * T - cy
                if t == "#":
                    s.blit(tiles["dirt" if r > 0 and self.grid[r - 1][c] == "#" else "top"][self.var[r][c]], (X, Y))
                elif t == "L":
                    s.blit(tiles["log"], (X, Y))
                elif t == "H":
                    s.blit(tiles["hedge"], (X, Y))
        if self.finish:
            fx, fy = self.finish
            s.blit(g.big_rainbow, g.big_rainbow.get_rect(midbottom=(fx - cx, fy - cy + 6)))
        for f in self.flags:
            s.blit(g.flag_imgs[f["on"]], g.flag_imgs[f["on"]].get_rect(midbottom=(f["x"] - cx, f["y"] - cy)))
        for p in self.pads:
            img = g.pad_img
            s.blit(img, img.get_rect(midbottom=(p["x"] - cx, p["y"] - cy + 4)))
            if self.pad_here() is p and not self.boulet and int(self.t * 3) % 2 == 0:
                g.txt.draw(s, btn(g.player, "b") + " : BOULET DE CANON !", 26, (p["x"] - cx, p["y"] - 170 - cy),
                           (255, 240, 120), outline=(150, 40, 120), ow=3)
        for c in self.crates:
            if c["alive"]:
                s.blit(g.crate_img, g.crate_img.get_rect(midbottom=(c["x"] - cx, c["y"] - cy)))
        for m in self.muffins:
            if m["alive"]:
                bob = math.sin(self.t * 3 + m["ph"]) * 4 if m["vy"] is None else 0
                s.blit(g.muffin_img, g.muffin_img.get_rect(center=(m["x"] - cx, m["y"] - cy + bob)))
        for cp in self.capys:
            img = g.capy_imgs[int(cp.t * 6) % 2][0 if cp.dir < 0 else 1]
            hop = 0
            if cp.fly:
                img = pygame.transform.rotate(img, cp.fly["t"] * 600)
            elif cp.leap:
                k = cp.leap["t"] / cp.leap["dur"]
                img = pygame.transform.rotate(img, -cp.dir * (25 - 50 * k))   # il se penche en avant, puis en arrière
            elif cp.aim > 0:
                hop = 4                                     # il lève sa gourde pour viser
                g.txt.draw(s, "!", 40, (cp.x - cx, cp.y - cy - 118), (150, 220, 90), outline=(40, 80, 30), ow=3)
            elif cp.dizzy <= 0:
                hop = abs(math.sin(cp.t * 6)) * 10          # il sautille, assis sur ses pattes arrière
            s.blit(img, img.get_rect(midbottom=(cp.x - cx, cp.y - cy + 4 - hop)))
            if cp.dizzy > 0:
                for k in range(3):
                    a = self.t * 5 + k * 2.1
                    pygame.draw.polygon(s, (255, 230, 60), I.star_points(cp.x - cx + math.cos(a) * 30, cp.y - cy - 110 + math.sin(a) * 8, 8))
            if cp.final or (self.gift and self.gift["capy"] is cp):
                self.draw_giant_muffin(s, cp, cx, cy)
            if cp.speech:
                g.bubble(s, speech_text(cp.speech), cp.x - cx, cp.y - cy - 134, cp.speech["text"])
        for j in self.jets:
            draw_jet(s, j["x"] - cx, j["y"] - cy)
        for d in self.debris:
            img = pygame.transform.rotate(tiles["log" if d["k"] == "log" else "hedge"], d["rot"])
            s.blit(img, img.get_rect(center=(int(d["x"] - cx), int(d["y"] - cy))))
        self.draw_licorne(s, cx, cy)
        for sp in self.sparks:
            pygame.draw.circle(s, sp.color, (int(sp.x - cx), int(sp.y - cy)), max(1, int(5 * (1 - sp.t / sp.life))))
        for f in self.floats:
            g.txt.draw(s, f.text, 22, (f.x - cx, f.y - cy), f.color)
        ox = -int(cx * 0.7) % W
        nimg, nx, ny = g.nears[bi]                       # les fleurs du premier plan (découpées au plus juste)
        s.blit(nimg, (ox - W + nx, H - near.get_height() + 30 + ny))
        s.blit(nimg, (ox + nx, H - near.get_height() + 30 + ny))
        if self.intro_t > 0:
            a = min(1.0, self.intro_t / 0.6, (3.0 - self.intro_t) / 0.3)
            num, name = self.data["name"].split("  ", 1)
            img = pygame.Surface((W, 200), pygame.SRCALPHA)
            g.txt.draw(img, "Niveau " + num, 40, (W / 2, 50), (255, 255, 255), outline=(110, 50, 150), ow=4)
            g.txt.draw(img, name, 70, (W / 2, 130), I.ARC[self.idx * 2 % len(I.ARC)], outline=(90, 30, 120), ow=5, title=True)
            img.set_alpha(int(255 * max(0.0, a)))
            s.blit(img, (0, 150))
        if self.banner > 0:
            k = min(1.0, (1.8 - self.banner) / 0.25)
            size = int(30 + 50 * k)
            col = I.ARC[int(self.t * 12) % len(I.ARC)]
            g.txt.draw(s, "BOULET DE CANON !", size, (W / 2, 170), col, outline=(90, 30, 120), ow=5, title=True)

    def draw_giant_muffin(self, s, cp, cx, cy):
        g = self.game
        gf = self.gift
        hx, hy = cp.x - 62, cp.y - 58                         # dans ses bras
        mx, my = self.x + 92 * self.facing, self.y - 70       # devant la bouche de Licorne
        size = 110
        if gf is None or gf["phase"] in ("walk", "give"):
            x, y = hx, hy + math.sin(self.t * 3) * 3
        elif gf["phase"] == "fly":
            k = min(1.0, gf["t"] / 0.8)
            x, y = hx + (mx - hx) * k, hy + (my - hy) * k - math.sin(math.pi * k) * 70
        elif gf["phase"] == "eat":
            k = min(1.0, gf["t"] / 2.6)
            x, y = mx, my
            size = int(110 * (1 - k))                          # elle le mange, bouchée par bouchée
        else:
            return
        if size > 6:
            img = pygame.transform.smoothscale(g.muffin_img, (size, size))
            s.blit(img, img.get_rect(center=(int(x - cx), int(y - cy))))

    def draw_licorne(self, s, cx, cy):
        g = self.game
        x, y = self.x - cx, self.y - cy
        if self.cloud:
            pf = g.cloud_img
            s.blit(pf, pf.get_rect(midtop=(x, y - 10)))
        if self.boulet and self.boulet["t"] < 0.6:
            # elle se ratatine : la tête et le corps rapetissent, comme un ressort qu'on écrase
            k = self.boulet["t"] / 0.6
            img = g.lic_side["squash"]
            w_, h_ = int(LW * (1 - 0.34 * k)), int(LH * (1 + 0.14 * k))
            img = pygame.transform.smoothscale(img, (w_, h_))
            if self.facing < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(midbottom=(x + math.sin(self.t * 60) * 2, y + 6)))
            return
        if self.boulet:
            # en vol : elle redevient normale, tout droit, sans tourner
            img = g.lic_side["jump"]
            if self.facing < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(midbottom=(x, y + 6)))
            return
        if self.done:
            img = g.lic_side["happy"]
        elif not self.on_ground:
            img = g.lic_side["jump"]
        elif abs(self.vx) > 30:
            img = g.lic_side["walk%d" % (int(self.anim * 8) % 2)]
        else:
            img = g.lic_side["normal"]
        if self.facing < 0:
            img = pygame.transform.flip(img, True, False)
        shake = 0
        if self.wet > 1.4:
            # toute verte de dégoût, les yeux plissés, elle frissonne
            img = toute_verte(g.lic_side["beurk"])          # même taille que d'habitude
            if self.facing < 0:
                img = pygame.transform.flip(img, True, False)
            shake = math.sin(self.t * 70) * 3
        elif self.wet > 0:
            img = vert_qui_part(img, self.wet / 1.4)        # le vert s'en va tout doucement
        hop = abs(math.sin(self.anim * 10)) * 6 if self.on_ground and abs(self.vx) > 30 else 0
        x += shake
        s.blit(img, img.get_rect(midbottom=(x, y + 6 - hop)))
        if self.speech:
            g.bubble(s, speech_text(self.speech), x, y - 146, self.speech["text"])

    def draw_hud(self, s):
        g = self.game
        panel(s, (12, 10, 420, 70), (255, 170, 220), (150, 110, 230), radius=18)
        s.blit(pygame.transform.smoothscale(g.muffin_img, (46, 46)), (24, 22))
        g.txt.draw(s, "%d / %d" % (self.eaten, self.total), 30, (78, 45), (255, 255, 255), "midleft", ow=3)
        g.txt.draw(s, "%d points" % self.score, 26, (230, 45), (255, 240, 140), "midleft", ow=3)
        # le bouton du Boulet de canon (n'importe quand)
        x0 = W - 330
        panel(s, (x0, 10, 318, 70), (140, 200, 255), (110, 110, 230), radius=18)
        g.txt.draw(s, "Boulet de canon", 20, (x0 + 159, 28), (255, 255, 255), ow=2)
        g.txt.draw(s, "bouton " + btn(g.player, "b"), 26, (x0 + 159, 56), (255, 240, 120), outline=(150, 40, 120), ow=3)
        if self.capy_ahead() and not self.boulet and int(self.t * 3) % 2 == 0:
            g.txt.draw(s, btn(g.player, "b") + " : BOULET DE CANON sur Capychou !", 24, (W - 16, 100), (255, 240, 120), "midright", outline=(150, 40, 120), ow=3)


# ============================================================================
# Jeu 2 : le lance-nuage
# ============================================================================
GROUND2 = 620
GRAV2 = 900


class Launcher:
    def __init__(self, game, ridx, easy=False):
        self.game = game
        self.ridx = ridx
        rd = ROUNDS[ridx % len(ROUNDS)]
        self.name = rd["name"]
        self.easy = easy
        self.shots = 5 + (2 if easy else 0)
        self.score = 0
        self.things = []
        bx0 = 0
        for kind, cx, cy in rd["things"]:
            x = cx * 64 - 100 + bx0
            if kind == "caisse":
                self.things.append({"k": "caisse", "x": x, "y": GROUND2 - cy * 64 - 32, "vx": 0.0, "vy": 0.0, "rot": 0.0, "vr": 0.0,
                                    "x0": x, "y0": GROUND2 - cy * 64 - 32, "moved": False, "fell": False})
            elif kind == "ballon":
                self.things.append({"k": "ballon", "x": x, "y": GROUND2 - cy * 64 - 40, "alive": True, "ph": random.uniform(0, 6),
                                    "r": 34 if easy else 26, "col": random.choice(((240, 100, 140), (110, 170, 250), (250, 200, 70), (140, 220, 120)))})
            elif kind == "muffin":
                self.things.append({"k": "muffin", "x": x, "y": GROUND2 - cy * 64 - 30, "alive": True, "ph": random.uniform(0, 6)})
            elif kind == "capy":
                self.things.append({"k": "capy", "x": x, "y": GROUND2 - cy * 64, "vx": 0.0, "vy": 0.0, "rot": 0.0, "hit": False, "fly": False})
        self.max_score = sum({"caisse": 30, "ballon": 25, "muffin": 30, "capy": 50}[t["k"]] for t in self.things)
        self.angle = 40.0
        self.power = 0.0
        self.charging = False
        self.ball = None
        self.state = "aim"
        self.wait = 0.0
        self.t = 0.0
        self.banner = 0.0
        self.sparks, self.floats = [], []
        self.speech = None
        self.capy_speech = None
        self.ox, self.oy = 190, GROUND2 - 150        # là où Licorne est assise dans le lance-nuage
        self.jets = []                               # le jet vert de la gourde de Capychou
        self.jet_cd = random.uniform(3.0, 5.0)
        self.wet = 0.0                               # toute verte de dégoût

    def add(self, n, x, y, col=(255, 240, 120)):
        self.score += n
        self.floats.append(Float(x, y, "+%d" % n, col))

    def update(self, dt):
        g = self.game
        dev = g.player
        self.t += dt
        self.banner = max(0.0, self.banner - dt)
        self.speech = speech_step(self.speech, dt)
        self.capy_speech = speech_step(self.capy_speech, dt)
        if self.state == "aim":
            if dev.held("u"):
                self.angle = min(75.0, self.angle + 40 * dt)
            if dev.held("d"):
                self.angle = max(10.0, self.angle - 40 * dt)
            if (dev.pressed("f") or dev.pressed("b")) and not self.charging:
                self.charging = True              # un nouvel appui : elle se ratatine…
                self.power = 0.0
                g.snd.play("ratatine")
            elif self.charging and (dev.held("f") or dev.held("b")):
                self.power = min(1.0, self.power + dt / 1.2)
            elif self.charging:
                self.launch()                     # … on lâche : BOULET DE CANON !
        elif self.state == "fly":
            self.update_ball(dt)
        elif self.state == "settle":
            self.wait -= dt
            if self.wait <= 0:
                self.shots -= 1
                if self.shots <= 0 or self.all_done():
                    self.state = "end"
                    g.snd.play("victoire")
                else:
                    self.state = "aim"
        self.update_things(dt)
        self.update_jets(dt)
        self.sparks = [s for s in self.sparks if s.update(dt)]
        self.floats = [f for f in self.floats if f.update(dt)]

    def update_jets(self, dt):
        """Capychou lance son jet vert sur Licorne pendant qu'elle vise. Si ça la touche, elle devient
        toute verte de dégoût (« Beurk ! »), mais on ne perd rien."""
        g = self.game
        self.wet = max(0.0, self.wet - dt)
        capys = [t for t in self.things if t["k"] == "capy" and not t["hit"] and not t["fly"]]
        if self.state == "aim" and capys and self.wet <= 0 and not self.jets:
            self.jet_cd -= dt
            if self.jet_cd <= 0:
                self.jet_cd = random.uniform(5.0, 8.0)
                t = random.choice(capys)
                x0, y0 = t["x"] - 26, t["y"] - 66
                tt = 1.5                                  # le temps du vol du jet jusqu'à Licorne
                ty = self.oy - 10
                self.jets.append({"x": x0, "y": y0, "vx": (self.ox - x0) / tt, "vy": (ty - y0 - 500 * tt * tt) / tt, "t": 0.0})
                self.capy_speech = speech(random.choice(CAPY_JET), 1.6)
                g.snd.play("capy")
                g.snd.play("pop", 0.6)
        r = pygame.Rect(self.ox - 60, self.oy - 50, 120, 90)
        for j in self.jets:
            j["t"] += dt
            j["vy"] += 1000 * dt
            j["x"] += j["vx"] * dt
            j["y"] += j["vy"] * dt
            if random.random() < 0.6:
                self.sparks.append(Spark(j["x"], j["y"], (150, 200, 90), 40))
            if self.state == "aim" and r.collidepoint(j["x"], j["y"]):
                j["done"] = True
                self.wet = 2.0
                g.snd.play("nuage")
                self.speech = speech(random.choice(LICORNE_BEURK), 1.6)
                g.snd.play("licorne", 0.8)
                for _ in range(22):
                    self.sparks.append(Spark(self.ox, self.oy, random.choice(((140, 200, 80), (170, 220, 110), (110, 170, 70)))))
            elif j["y"] > GROUND2 or j["t"] > 3:
                j["done"] = True
                for _ in range(10):
                    self.sparks.append(Spark(j["x"], min(j["y"], GROUND2) - 4, (140, 190, 80), 120))
        self.jets = [j for j in self.jets if not j.get("done")]

    def all_done(self):
        return all((t["k"] == "caisse" and t["fell"]) or (t["k"] in ("ballon", "muffin") and not t["alive"]) or (t["k"] == "capy" and t["hit"])
                   for t in self.things)

    def launch(self):
        g = self.game
        self.charging = False
        v = 480 + 860 * self.power
        a = math.radians(self.angle)
        self.ball = {"x": self.ox, "y": self.oy, "vx": math.cos(a) * v, "vy": -math.sin(a) * v, "t": 0.0, "still": 0.0, "rot": 0.0}
        self.state = "fly"
        self.banner = 1.4
        g.snd.play("boulet")

    def update_ball(self, dt):
        g = self.game
        b = self.ball
        b["t"] += dt
        b["vy"] += GRAV2 * dt
        b["x"] += b["vx"] * dt
        b["y"] += b["vy"] * dt
        b["rot"] -= b["vx"] * dt * 2
        R = 32
        if random.random() < 0.8:
            self.sparks.append(Spark(b["x"], b["y"], random.choice(I.ARC), 60))
        if b["y"] > GROUND2 - R:
            b["y"] = GROUND2 - R
            if abs(b["vy"]) > 120:
                g.snd.play("boing", 0.5)
            b["vy"] = -b["vy"] * 0.35
            b["vx"] *= 0.7
        for t in self.things:
            if t["k"] == "caisse":
                rr = pygame.Rect(t["x"] - 32, t["y"] - 32, 64, 64)
                nx, ny = clamp(b["x"], rr.left, rr.right), clamp(b["y"], rr.top, rr.bottom)
                if (nx - b["x"]) ** 2 + (ny - b["y"]) ** 2 < R * R:
                    t["vx"] += b["vx"] * 0.55
                    t["vy"] += -abs(b["vy"]) * 0.2 - 120
                    t["vr"] = random.choice((-1, 1)) * random.uniform(120, 300)
                    g.snd.play("caisse", 0.7)
                    b["vx"] *= -0.35 if abs(nx - b["x"]) > abs(ny - b["y"]) else 0.6
                    b["vy"] *= 0.6
                    b["x"] += -R * 0.3 if b["vx"] < 0 else 0
            elif t["k"] in ("ballon", "muffin") and t["alive"]:
                rad = t.get("r", 30)
                if (t["x"] - b["x"]) ** 2 + (t["y"] - b["y"]) ** 2 < (R + rad) ** 2:
                    t["alive"] = False
                    if t["k"] == "ballon":
                        g.snd.play("pop")
                        self.add(25, t["x"], t["y"])
                        for _ in range(14):
                            self.sparks.append(Spark(t["x"], t["y"], t["col"]))
                    else:
                        g.snd.play("miam")
                        self.add(30, t["x"], t["y"], (160, 240, 120))
                        self.speech = speech(random.choice(EAT), 1.2)
                        g.snd.play("licorne", 0.6)
            elif t["k"] == "capy" and not t["fly"]:
                if abs(t["x"] - b["x"]) < 60 and -120 < b["y"] - t["y"] < 20:
                    self.capy_flies(t, b["vx"])
        if b["x"] > W + 80 or b["x"] < -80 or b["t"] > 6:
            self.end_shot()
        elif b["y"] >= GROUND2 - R - 1 and abs(b["vx"]) < 40:
            b["still"] += dt
            if b["still"] > 0.4:
                self.end_shot()

    def capy_flies(self, t, vx):
        g = self.game
        t["fly"] = True
        t["vx"] = 220 if vx >= 0 else -220
        t["vy"] = -420
        if not t["hit"]:
            t["hit"] = True
            self.add(50, t["x"], t["y"] - 60, (255, 200, 140))
            self.capy_speech = speech(random.choice(("Hihi ! Bien visé !", "Ouh là ! Je vole !", "Pas mes caisses !")), 2.0)
            g.snd.play("capy")

    def end_shot(self):
        self.ball = None
        self.state = "settle"
        self.wait = 1.0

    def update_things(self, dt):
        crates = [t for t in self.things if t["k"] == "caisse"]
        crates.sort(key=lambda t: -t["y"])
        for t in crates:
            t["vy"] += GRAV2 * dt
            prev_bottom = t["y"] + 32
            t["x"] += t["vx"] * dt
            t["y"] += t["vy"] * dt
            t["vx"] *= (1 - min(1, dt * 1.5))
            t["rot"] += t["vr"] * dt
            if t["y"] + 32 >= GROUND2:
                t["y"] = GROUND2 - 32
                if t["vy"] > 80:
                    t["vr"] *= 0.5
                t["vy"] = 0
                t["vx"] *= (1 - min(1, dt * 6))
                if not t["fell"] and t["y0"] < GROUND2 - 40:
                    t["fell"] = True
                    self.add(20, t["x"], t["y"] - 50)
            else:
                for o in crates:
                    if o is t:
                        continue
                    if abs(o["x"] - t["x"]) < 44 and prev_bottom <= o["y"] - 32 + 6 and t["y"] + 32 >= o["y"] - 32:
                        t["y"] = o["y"] - 64
                        t["vy"] = 0
                        t["vx"] *= (1 - min(1, dt * 6))
                        break
            if abs(t["vx"]) < 8 and t["vy"] == 0:
                t["vr"] *= (1 - min(1, dt * 8))
                t["rot"] += (round(t["rot"] / 90) * 90 - t["rot"]) * min(1, dt * 6)
            if not t["moved"] and (abs(t["x"] - t["x0"]) > 18 or abs(t["y"] - t["y0"]) > 18):
                t["moved"] = True
                self.add(10, t["x"], t["y"] - 40)
                if t["y0"] >= GROUND2 - 40:
                    t["fell"] = True
                    self.add(20, t["x"], t["y"] - 70)
        # Capy tombe si ses caisses s'en vont
        for t in self.things:
            if t["k"] != "capy":
                continue
            if t["fly"]:
                t["vy"] += GRAV2 * dt
                t["x"] += t["vx"] * dt
                t["y"] += t["vy"] * dt
                t["rot"] += 400 * dt
                if t["y"] >= GROUND2:
                    t["y"] = GROUND2
                    t["fly"] = False
                    t["vx"] = 0
                    t["rot"] = 0
                continue
            support = t["y"] >= GROUND2 - 1 or any(o["k"] == "caisse" and abs(o["x"] - t["x"]) < 50 and abs((o["y"] - 32) - t["y"]) < 8 for o in self.things)
            if not support:
                self.capy_flies(t, 0)

    def stars(self):
        k = self.score / max(1, self.max_score)
        return 3 if k >= 0.75 else 2 if k >= 0.45 else 1 if k >= 0.2 else 0

    def draw(self, s):
        g = self.game
        s.blit(g.flats[0], (0, 0))
        for x in range(0, W, T):
            s.blit(g.tiles["top"][(x // T) % 3], (x, GROUND2))
            s.blit(g.tiles["dirt"][(x // T) % 3], (x, GROUND2 + T))
        s.blit(g.catapult_img, g.catapult_img.get_rect(midbottom=(self.ox, GROUND2)))
        for t in self.things:
            if t["k"] == "caisse":
                img = pygame.transform.rotate(g.crate_img, t["rot"])
                s.blit(img, img.get_rect(center=(t["x"], t["y"])))
            elif t["k"] == "ballon" and t["alive"]:
                img = g.balloon_imgs[t["col"]]
                if t.get("r", 26) > 30:
                    img = pygame.transform.smoothscale(img, (64, 115))
                s.blit(img, img.get_rect(midtop=(t["x"], t["y"] - img.get_height() * 0.33 + math.sin(self.t * 2 + t["ph"]) * 6)))
            elif t["k"] == "muffin" and t["alive"]:
                s.blit(g.muffin_img, g.muffin_img.get_rect(center=(t["x"], t["y"] + math.sin(self.t * 3 + t["ph"]) * 4)))
        for t in self.things:
            if t["k"] == "capy":
                img = g.capy_imgs[0][0]
                if t["fly"]:
                    img = pygame.transform.rotate(img, t["rot"])
                s.blit(img, img.get_rect(midbottom=(t["x"], t["y"] + 4)))
                if self.capy_speech:
                    g.bubble(s, speech_text(self.capy_speech), t["x"], t["y"] - 128, self.capy_speech["text"])
        # Licorne dans le lance-nuage (elle se ratatine pendant qu'on charge)
        if self.state == "aim":
            if self.charging:
                k = self.power
                img = pygame.transform.smoothscale(g.lic_side["squash"], (int(140 * (1 - 0.34 * k)), int(108 * (1 + 0.14 * k))))
                if self.wet > 0:
                    img = vert_qui_part(img, self.wet / 1.0)
                s.blit(img, img.get_rect(midbottom=(self.ox + math.sin(self.t * 60) * 2 * k, self.oy + 40)))
            elif self.wet > 1.0:
                # toute verte de dégoût, les yeux plissés, elle frissonne
                img = toute_verte(pygame.transform.smoothscale(g.lic_side["squash"], (140, 108)))
                s.blit(img, img.get_rect(midbottom=(self.ox + math.sin(self.t * 70) * 3, self.oy + 40)))
            else:
                img = g.lic_side_small
                if self.wet > 0:
                    img = vert_qui_part(img, self.wet / 1.0)    # le vert s'en va tout doucement
                s.blit(img, img.get_rect(midbottom=(self.ox, self.oy + 40)))
            # la ligne en pointillés qui aide à viser
            v = 480 + 860 * (self.power if self.charging else 0.5)
            a = math.radians(self.angle)
            x, y, vx, vy = self.ox, self.oy, math.cos(a) * v, -math.sin(a) * v
            for k in range(22 if not self.easy else 34):
                for _ in range(3):
                    vy += GRAV2 / 60
                    x += vx / 60
                    y += vy / 60
                if y > GROUND2:
                    break
                pygame.draw.circle(s, (255, 255, 255), (int(x), int(y)), 5)
                pygame.draw.circle(s, (200, 120, 230), (int(x), int(y)), 3)
            if self.charging:
                pygame.draw.rect(s, (60, 40, 90), (self.ox - 60, GROUND2 + 20, 120, 16), border_radius=8)
                pygame.draw.rect(s, I.ARC[int(self.t * 10) % 6], (self.ox - 60, GROUND2 + 20, int(120 * self.power), 16), border_radius=8)
        for j in self.jets:
            draw_jet(s, j["x"], j["y"])
        if self.ball:
            b = self.ball
            img = g.lic_side_small                # en vol : elle redevient normale
            ang = math.degrees(math.atan2(-b["vy"], b["vx"])) * 0.4 if abs(b["vx"]) > 30 else 0      # elle suit un peu la pente, sans tourner
            img = pygame.transform.rotate(img, ang)
            s.blit(img, img.get_rect(center=(int(b["x"]), int(b["y"]))))
        if self.speech:
            g.bubble(s, speech_text(self.speech), self.ox, self.oy - 50, self.speech["text"])
        for sp in self.sparks:
            pygame.draw.circle(s, sp.color, (int(sp.x), int(sp.y)), max(1, int(5 * (1 - sp.t / sp.life))))
        for f in self.floats:
            g.txt.draw(s, f.text, 24, (f.x, f.y), f.color)
        if self.banner > 0:
            k = min(1.0, (1.4 - self.banner) / 0.2)
            g.txt.draw(s, "BOULET DE CANON !", int(30 + 50 * k), (W / 2, 170), I.ARC[int(self.t * 12) % 6], outline=(90, 30, 120), ow=5, title=True)
        # le bandeau
        panel(s, (12, 10, W - 24, 64), (255, 170, 220), (150, 110, 230), radius=18)
        g.txt.draw(s, "Manche %d : %s" % (self.ridx + 1, self.name), 26, (30, 42), (255, 255, 255), "midleft", ow=3)
        g.txt.draw(s, "%d points" % self.score, 28, (W / 2 + 120, 42), (255, 240, 140), ow=3)
        for k in range(self.shots):
            img = g.lic_icon
            s.blit(img, (W - 60 - k * 46, 20))
        if self.state == "aim" and not self.charging:
            g.txt.draw(s, "HAUT / BAS : viser    garde %s appuyé, puis lâche : BOULET DE CANON !" % btn(g.player, "f"), 22, (W / 2, H - 24),
                       (255, 255, 255), outline=(90, 30, 120), ow=3)


# ============================================================================
# Le jeu
# ============================================================================
class Game:
    def __init__(self):
        pygame.mixer.pre_init(22050, -16, 2, 512)
        pygame.init()
        pygame.mixer.set_num_channels(20)
        pygame.mixer.set_reserved(1)
        pygame.display.set_caption(TITLE)
        if WEB:
            self.screen = pygame.display.set_mode((W, H))     # le navigateur adapte la taille tout seul
        else:
            self.screen = pygame.display.set_mode((W, H), pygame.SCALED | (0 if os.environ.get("POPO_WINDOW") else pygame.FULLSCREEN), vsync=1)
            pygame.mouse.set_visible(False)
        self.touch = Touch()
        self.clock = pygame.time.Clock()
        self.txt = Txt()
        self.base = base_dir()
        self.save_path = os.path.join(self.base, "sauvegarde.json")
        self.save = {"unlocked": 1, "stars": {}, "best_lancer": 0}
        try:
            if WEB:
                import platform as pf                     # dans le navigateur : la sauvegarde reste dans le navigateur
                data = pf.window.localStorage.getItem("licorne_sauvegarde")
                if data:
                    self.save.update(json.loads(str(data)))
            else:
                with open(self.save_path, "r", encoding="utf-8") as f:
                    self.save.update(json.load(f))
        except Exception:
            pass
        self.loading(0.1)
        self.lic_side = {"normal": self.sc(I.licorne_side()), "happy": self.sc(I.licorne_side("happy")),
                         "walk0": self.sc(I.licorne_side("normal", 0)), "walk1": self.sc(I.licorne_side("normal", 1)),
                         "jump": self.sc(I.licorne_side("happy", 1)), "squash": I.licorne_side("squash"),
                         "beurk": self.sc(I.licorne_side("squash"))}
        self.lic_side_small = pygame.transform.smoothscale(I.licorne_side(), (140, 108))
        self.lic_front = I.licorne_front()
        self.lic_front_happy = I.licorne_front("happy")
        self.lic_icon = pygame.transform.smoothscale(I.licorne_front(), (40, 40))
        cp = [I.capy("normal", 0), I.capy("normal", 1)]
        self.capy_imgs = [(pygame.transform.smoothscale(c, (90, 126)), pygame.transform.flip(pygame.transform.smoothscale(c, (90, 126)), True, False)) for c in cp]
        self.capy_face = pygame.transform.smoothscale(I.capy_front("happy"), (150, 160))
        self.loading(0.3)
        self.muffin_img = I.muffin(52)
        self.crate_img = I.caisse_muffins(64)
        self.tiles = I.make_tiles()
        self.pad_img = I.pad()
        self.catapult_img = I.catapult()
        self.cloud_img = I.cloud_puff(36)
        self.big_rainbow = I.rainbow_arc(360, 200)
        self.flag_imgs = {False: self.flag(False), True: self.flag(True)}
        self.balloon_imgs = {c: I.balloon(c) for c in ((240, 100, 140), (110, 170, 250), (250, 200, 70), (140, 220, 120))}
        self.star_on, self.star_off = I.star_icon(True, 56), I.star_icon(False, 56)
        self.bg = I.make_background(W, H, 3)
        self.bgs = [self.bg, I.make_background(W, H, 5, theme=1), I.make_background(W, H, 7, theme=2)]
        # pour aller plus vite : le ciel, les collines et les arbres en une seule image (sans transparence),
        # et les fleurs du premier plan découpées au plus juste
        self.flats, self.nears = [], []
        for sky, far, mid, near in self.bgs:
            f = pygame.Surface((W, H + 40))
            f.blit(sky, (0, 0))
            f.blit(far, (0, 0))
            f.blit(mid, (0, 0))
            f.blit(pygame.transform.scale(f.subsurface((0, H - 1, W, 1)), (W, 40)), (0, H))
            self.flats.append(f.convert())
            r = near.get_bounding_rect()
            self.nears.append((near.subsurface(r).copy().convert_alpha(), r.x, r.y))
        self.loading(0.45)
        self.snd = Sounds(self.base, lambda k: self.loading(0.45 + 0.55 * k))
        self.devices = [Device("kb"), Device("kb2"), Device("touch", self.touch)]
        self.player = self.devices[0]
        self.state = "title"
        self.sel = 0
        self.t = 0.0
        self.adv = None
        self.lan = None
        self.dialog = None
        self.paused = False
        self.snd.start_music()

    def sc(self, img):
        return pygame.transform.smoothscale(img, (LW, LH))

    def flag(self, on):
        s = pygame.Surface((70, 130), pygame.SRCALPHA)
        pygame.draw.rect(s, (150, 104, 64), (8, 10, 8, 120))
        if on:
            for i, c in enumerate(I.ARC):
                pygame.draw.rect(s, c, (16, 12 + i * 7, 50, 7))
        else:
            pygame.draw.polygon(s, (190, 190, 200), [(16, 12), (66, 30), (16, 50)])
        return s

    def loading(self, k):
        pygame.event.pump()
        s = self.screen
        s.fill((200, 170, 240))
        self.txt.draw(s, TITLE, 80, (W / 2, H / 2 - 60), (255, 255, 255), outline=(150, 80, 200), ow=5, title=True)
        self.txt.draw(s, "Licorne prépare ses muffins…", 26, (W / 2, H / 2 + 20), outline=(120, 60, 170))
        pygame.draw.rect(s, (120, 80, 170), (W / 2 - 250, H / 2 + 70, 500, 26), border_radius=13)
        pygame.draw.rect(s, (255, 230, 120), (W / 2 - 250, H / 2 + 70, int(500 * k), 26), border_radius=13)
        pygame.display.flip()

    def write_save(self):
        try:
            if WEB:
                import platform as pf
                pf.window.localStorage.setItem("licorne_sauvegarde", json.dumps(self.save))
            else:
                with open(self.save_path, "w", encoding="utf-8") as f:
                    json.dump(self.save, f)
        except Exception:
            pass

    def bubble(self, surf, shown, x, y, full):
        lines = self.txt.wrap(full, 20, 280)
        w = max(self.txt.font(20).size(l)[0] for l in lines) + 28
        h = len(lines) * 28 + 16
        r = pygame.Rect(0, 0, w, h)
        r.midbottom = (x, y)
        r.clamp_ip(pygame.Rect(4, 90, W - 8, H - 100))
        tip = clamp(x, r.left + 14, r.right - 14)
        pygame.draw.polygon(surf, (150, 90, 190), [(tip - 10, r.bottom - 2), (tip + 10, r.bottom - 2), (tip, r.bottom + 16)])
        pygame.draw.rect(surf, (255, 255, 255), r, border_radius=14)
        pygame.draw.rect(surf, (150, 90, 190), r, 3, border_radius=14)
        rem = len(shown)
        yy = r.y + 8
        for l in lines:
            part = l[:max(0, rem)]
            rem -= len(l) + 1
            if part:
                self.txt.draw(surf, part, 20, (r.x + 14, yy), (70, 40, 90), "topleft", None)
            yy += 28

    def refresh_joys(self):
        devs = [d for d in self.devices if d.kind in ("kb", "kb2", "touch")]
        for i in range(pygame.joystick.get_count()):
            try:
                j = pygame.joystick.Joystick(i)
                j.init()
                devs.append(Device("joy", j, i + 1))
            except pygame.error:
                pass
        self.devices = devs
        if self.player not in devs:
            self.player = next((d for d in devs if d.name == self.player.name), devs[0])

    def note_button(self, ev):
        """Écrit dans manette.txt les derniers boutons appuyés (pour savoir quel bouton porte quel numéro)."""
        self.btn_log = (getattr(self, "btn_log", []) + ["manette %s : bouton %d" % (getattr(ev, "instance_id", getattr(ev, "joy", "?")), ev.button)])[-30:]
        try:
            with open(os.path.join(self.base, "manette.txt"), "w", encoding="utf-8") as f:
                f.write("Les derniers boutons appuyés sur la manette (le plus récent en bas) :\n" + "\n".join(self.btn_log) + "\n")
        except Exception:
            pass

    def any_pressed(self, k):
        for d in self.devices:
            if d.pressed(k):
                self.player = d          # celle qui appuie joue (clavier ou manette)
                return True
        return False

    def double_fire(self):
        quick = self.t - getattr(self, "_last_fire", -9.0) < 0.45
        self._last_fire = self.t
        return quick

    def step(self):
        """Une image du jeu. Renvoie False quand on quitte."""
        # (dans le navigateur, un téléphone lent fait moins d'images : on avance un peu plus à chaque image
        #  pour que le jeu ne tourne pas au ralenti)
        dt = min(self.clock.tick(60) / 1000.0, 1 / 20 if WEB else 1 / 30)
        self.t += dt
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_F11 and not WEB:
                pygame.display.toggle_fullscreen()
            if ev.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
                self.refresh_joys()
            if ev.type == pygame.JOYBUTTONDOWN:
                self.note_button(ev)
            self.touch.event(ev)
        keys = pygame.key.get_pressed()
        self.touch_layout()
        for d in self.devices:
            d.poll(keys)
        if getattr(self, "state_" + self.state)(dt) == "quit":
            return False
        self.touch.draw(self.screen, self.txt)
        pygame.display.flip()
        if WEB:
            # combien d'images par seconde (visible dans la console du navigateur, pour régler la vitesse)
            now = pygame.time.get_ticks()
            if not hasattr(self, "_fps"):
                self._fps = [0, now]
            self._fps[0] += 1
            if now - self._fps[1] >= 3000:
                try:
                    import platform as pf
                    pf.window.console.log("FPS %.1f (%s)" % (self._fps[0] * 1000 / (now - self._fps[1]), self.state))
                except Exception:
                    pass
                self._fps = [0, now]
        return True

    def leave(self):
        """Quitter le jeu. Dans le navigateur : retour à la page « Nos jeux »."""
        self.write_save()
        if WEB:
            try:
                import platform as pf
                pf.window.location.href = "../"
            except Exception:
                pass
            return None
        return "quit"

    def touch_layout(self):
        """Quels boutons tactiles montrer, et ce qui est écrit dessus, selon l'écran du jeu."""
        tc = self.touch
        if self.state == "adventure" and not self.paused and not self.dialog:
            tc.show = {"l", "r", "f", "b", "start"}
            tc.labels = {"f": "Saut", "b": "Boulet"}
        elif self.state == "lancer" and not self.paused:
            tc.show = {"u", "d", "f", "start"}
            tc.labels = {"f": "Lancer"}
        else:
            tc.show = {"l", "r", "u", "d", "f", "start"}
            tc.labels = {"f": "OK", "start": "x"}      # dans les menus, le bouton du haut est une croix (retour / sortir)
        tc.btns["start"] = (W - 48, 46, 32) if tc.labels.get("start") == "x" else Touch.BTNS["start"]
        tc.update()

    def run(self):
        self.refresh_joys()
        while self.step():
            pass

    async def run_async(self):
        """Pour le navigateur : on rend la main au navigateur après chaque image."""
        self.refresh_joys()
        while self.step():
            await asyncio.sleep(0)

    # --- menus
    def title_bg(self, s):
        s.blit(self.flats[0], (0, 0))
        for x in range(0, W, T):
            s.blit(self.tiles["top"][(x // T) % 3], (x, H - 2 * T))
            s.blit(self.tiles["dirt"][(x // T) % 3], (x, H - T))

    def state_title(self, dt):
        s = self.screen
        self.title_bg(s)
        self.txt.draw(s, "Licorne", 120, (W / 2, 100), (255, 255, 255), outline=(170, 80, 210), ow=7, title=True)
        self.txt.draw(s, "et les muffins à l'herbe", 34, (W / 2, 185), (255, 240, 140), outline=(120, 60, 170), ow=3)
        hop = abs(math.sin(self.t * 3)) * 30
        img = self.lic_front_happy if int(self.t) % 3 == 0 else self.lic_front
        s.blit(img, img.get_rect(midbottom=(W / 2 - 300, H - 2 * T + 14 - hop)))
        s.blit(self.capy_face, self.capy_face.get_rect(midbottom=(W / 2 + 320, H - 2 * T + 10)))
        for k in range(4):
            m = self.muffin_img
            s.blit(m, m.get_rect(center=(W / 2 - 120 + k * 80, H - 2 * T - 30 + math.sin(self.t * 3 + k) * 8)))
        opts = ["L'aventure", "Le lance-nuage", "Sortir du jeu" if WEB else "Quitter"]
        if self.any_pressed("u"):
            self.sel = (self.sel - 1) % len(opts)
            self.snd.play("menu")
        if self.any_pressed("d"):
            self.sel = (self.sel + 1) % len(opts)
            self.snd.play("menu")
        for i, o in enumerate(opts):
            on = i == self.sel
            r = pygame.Rect(0, 0, 420 if on else 380, 64 if on else 56)
            r.center = (W / 2, 290 + i * 80)
            panel(s, r, (255, 150, 210) if on else (200, 180, 240), (160, 100, 230) if on else (140, 130, 200), (255, 240, 120) if on else (255, 255, 255), radius=24)
            self.txt.draw(s, o, 36 if on else 30, r.center, (255, 255, 255), outline=(110, 50, 150), ow=3)
        hint = "Flèches pour choisir, ESPACE (ou A) pour jouer" + ("    ·    Téléphone : touchez l'écran" if WEB else "    ·    F11 : plein écran")
        self.txt.draw(s, hint, 20, (W / 2, H - 22), outline=(110, 50, 150))
        if self.any_pressed("f"):
            self.snd.play("valide")
            if self.sel == 0:
                self.state = "levels"
                self.lsel = min(self.save["unlocked"], len(LEVELS)) - 1
            elif self.sel == 1:
                self.ridx = 0
                self.lan = Launcher(self, 0)
                self.state = "lancer"
            else:
                return self.leave()
        elif self.any_pressed("start"):
            return self.leave()

    def state_levels(self, dt):
        s = self.screen
        self.title_bg(s)
        self.txt.draw(s, "L'aventure de Licorne", 60, (W / 2, 80), (255, 255, 255), outline=(170, 80, 210), ow=5, title=True)
        n = min(self.save["unlocked"], len(LEVELS))
        if self.any_pressed("l"):
            self.lsel = max(0, self.lsel - 1)
            self.snd.play("menu")
        if self.any_pressed("r"):
            self.lsel = min(n - 1, self.lsel + 1)
            self.snd.play("menu")
        for i, lv in enumerate(LEVELS):
            name = lv()["name"]
            x = W / 2 + (i - 1) * 380
            r = pygame.Rect(0, 0, 340, 300)
            r.center = (x, 360)
            locked = i >= n
            on = i == self.lsel
            panel(s, r, (255, 160, 215) if not locked else (190, 190, 200), (150, 110, 230) if not locked else (140, 140, 150),
                  (255, 240, 120) if on else (255, 255, 255), radius=26)
            self.txt.draw(s, "Niveau " + name.split("  ")[0], 34, (x, r.y + 40), (255, 255, 255), outline=(110, 50, 150), ow=3)
            for k, l in enumerate(self.txt.wrap(name.split("  ", 1)[1], 24, 300)):
                self.txt.draw(s, l, 24, (x, r.y + 90 + k * 30), (255, 255, 255), outline=(110, 50, 150))
            if locked:
                self.txt.draw(s, "?", 80, (x, r.y + 200), (255, 255, 255), outline=(110, 110, 120), ow=4)
            else:
                st = self.save["stars"].get(str(i), 0)
                for k in range(3):
                    img = self.star_on if k < st else self.star_off
                    s.blit(img, img.get_rect(center=(x - 64 + k * 64, r.y + 210)))
        self.txt.draw(s, "Gauche / droite pour choisir, ESPACE (ou A) pour jouer, Échap : retour", 22, (W / 2, H - 30), outline=(110, 50, 150))
        if self.any_pressed("f"):
            self.snd.play("valide")
            self.start_adventure(self.lsel)
        elif self.any_pressed("start"):
            self.state = "title"

    def start_adventure(self, idx):
        self.adv = Adventure(self, idx)
        self.state = "adventure"
        self.paused = False
        self.dialog = None                    # pas de dialogue : on joue tout de suite

    # --- dialogues (au début de chaque niveau)
    def draw_dialog(self, s):
        d = self.dialog
        who, text = d["lines"][d["i"]]
        lines = self.txt.wrap(text, 26, 640)
        box = pygame.Rect(W / 2 - 430, 110, 860, 70 + len(lines) * 36)
        panel(s, box, COLS[who], (90, 60, 160))
        face = self.lic_front if who == "licorne" else self.capy_face
        face = pygame.transform.smoothscale(face, (120, 120))
        s.blit(face, face.get_rect(midleft=(box.x + 14, box.centery)))
        self.txt.draw(s, NAMES[who], 26, (box.x + 150, box.y + 12), (255, 255, 160), "topleft", (60, 30, 90))
        shown = speech_text(d["sp"])
        rem = len(shown)
        y = box.y + 48
        for l in lines:
            part = l[:max(0, rem)]
            rem -= len(l) + 1
            if part:
                self.txt.draw(s, part, 26, (box.x + 150, y), (255, 255, 255), "topleft", (60, 30, 90))
            y += 36
        self.txt.draw(s, "%s > (2 fois vite : passer)" % btn(self.player, "f"), 18, (box.right - 16, box.bottom - 8), (255, 255, 200), "bottomright", None)

    def update_dialog(self, dt):
        d = self.dialog
        d["sp"] = speech_step(d["sp"], dt) or d["sp"]
        if self.any_pressed("f"):
            if self.double_fire():
                self.dialog = None
                return
            if d["sp"]["k"] < len(d["sp"]["marks"]):
                d["sp"]["k"] = len(d["sp"]["marks"])
            else:
                d["i"] += 1
                if d["i"] >= len(d["lines"]):
                    self.dialog = None
                else:
                    d["sp"] = speech(d["lines"][d["i"]][1], 999)
        elif self.any_pressed("start"):
            self.dialog = None

    # --- l'aventure
    def state_adventure(self, dt):
        s = self.screen
        a = self.adv
        if self.dialog:
            self.update_dialog(dt)
            a.draw(s)
            a.draw_hud(s)
            if self.dialog:
                self.draw_dialog(s)
            return
        if self.paused:
            a.draw(s)
            return self.draw_pause(s)
        if self.any_pressed("start"):
            self.paused = True
            self.pause_sel = 0
            self.snd.play("menu")
            return
        a.update(dt)
        a.draw(s)
        a.draw_hud(s)
        if a.scene_over():
            k = a.eaten / max(1, a.total)
            st = 3 if k >= 0.85 else 2 if k >= 0.5 else 1          # finir le niveau, c'est déjà une étoile
            key = str(a.idx)
            self.save["stars"][key] = max(self.save["stars"].get(key, 0), st)
            self.save["unlocked"] = max(self.save["unlocked"], a.idx + 2)
            self.write_save()
            self.res = {"stars": st, "score": a.score, "eaten": a.eaten, "total": a.total, "t": 0.0}
            self.state = "adv_results"

    def state_adv_results(self, dt):
        s = self.screen
        r = self.res
        r["t"] += dt
        self.title_bg(s)
        self.txt.draw(s, "Bravo Licorne !", 70, (W / 2, 90), (255, 255, 255), outline=(170, 80, 210), ow=5, title=True)
        for k in range(3):
            img = self.star_on if k < r["stars"] else self.star_off
            if r["t"] > 0.4 + k * 0.4:
                if k < r["stars"] and not r.get("ding%d" % k):
                    r["ding%d" % k] = True
                    self.snd.play("etoile")
                big = pygame.transform.smoothscale(img, (110, 110))
                s.blit(big, big.get_rect(center=(W / 2 - 140 + k * 140, 230)))
        self.txt.draw(s, "Muffins mangés : %d / %d" % (r["eaten"], r["total"]), 34, (W / 2, 340), (255, 255, 255), outline=(110, 50, 150), ow=3)
        self.txt.draw(s, "%d points" % r["score"], 34, (W / 2, 390), (255, 240, 140), outline=(110, 50, 150), ow=3)
        s.blit(self.lic_front_happy, self.lic_front_happy.get_rect(midbottom=(W / 2 - 300, H - 2 * T + 14 - abs(math.sin(self.t * 4)) * 30)))
        last = self.adv.idx + 1 >= len(LEVELS)
        if last:
            s.blit(self.capy_face, self.capy_face.get_rect(midbottom=(W / 2 + 300, H - 2 * T + 14)))
            big = pygame.transform.smoothscale(self.muffin_img, (130, 130))
            s.blit(big, big.get_rect(center=(W / 2 + 160, H - 2 * T - 70 + math.sin(self.t * 3) * 6)))
        msg = "Tu as fini toute l'aventure ! Capychou t'offre un muffin géant !" if last else "Niveau suivant : %s" % LEVELS[self.adv.idx + 1]()["name"].split("  ", 1)[1]
        self.txt.draw(s, msg, 26, (W / 2, 450), (255, 255, 255), outline=(110, 50, 150))
        if r["t"] > 1.5 and int(self.t * 2) % 2 == 0:
            self.txt.draw(s, "ESPACE (ou A) pour continuer", 28, (W / 2, H - 180), outline=(110, 50, 150), ow=3)
        if r["t"] > 1.5 and self.any_pressed("f"):
            self.snd.play("valide")
            if last:
                self.state = "levels"
            else:
                self.start_adventure(self.adv.idx + 1)

    # --- le lance-nuage
    def state_lancer(self, dt):
        s = self.screen
        ln = self.lan
        if self.paused:
            ln.draw(s)
            return self.draw_pause(s)
        if self.any_pressed("start"):
            self.paused = True
            self.pause_sel = 0
            self.snd.play("menu")
            return
        ln.update(dt)
        ln.draw(s)
        if ln.state == "end":
            st = ln.stars()
            self.save["best_lancer"] = max(self.save.get("best_lancer", 0), ln.score)
            self.write_save()
            self.res = {"stars": st, "score": ln.score, "t": 0.0}
            self.state = "lan_results"

    def state_lan_results(self, dt):
        s = self.screen
        r = self.res
        r["t"] += dt
        self.lan.draw(s)
        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((60, 30, 90, 150))
        s.blit(ov, (0, 0))
        st = r["stars"]
        self.txt.draw(s, "Bravo !" if st else "Presque !", 80, (W / 2, 140), (255, 255, 255), outline=(170, 80, 210), ow=5, title=True)
        for k in range(3):
            img = self.star_on if k < st else self.star_off
            if r["t"] > 0.4 + k * 0.4:
                if k < st and not r.get("ding%d" % k):
                    r["ding%d" % k] = True
                    self.snd.play("etoile")
                big = pygame.transform.smoothscale(img, (100, 100))
                s.blit(big, big.get_rect(center=(W / 2 - 130 + k * 130, 270)))
        self.txt.draw(s, "%d points" % r["score"], 40, (W / 2, 370), (255, 240, 140), outline=(110, 50, 150), ow=3)
        if st == 0:
            self.txt.draw(s, "Ce n'est pas grave ! La prochaine manche est plus facile.", 28, (W / 2, 430), outline=(110, 50, 150))
        self.txt.draw(s, "Meilleur score : %d" % self.save.get("best_lancer", 0), 24, (W / 2, 475), (255, 255, 220), outline=(110, 50, 150))
        if r["t"] > 1.2:
            self.txt.draw(s, "%s : manche suivante     Échap : menu" % btn(self.player, "f"), 28, (W / 2, 560), outline=(110, 50, 150), ow=3)
            if self.any_pressed("f"):
                self.snd.play("valide")
                self.ridx += 1
                self.lan = Launcher(self, self.ridx, easy=(st == 0))
                self.state = "lancer"
            elif self.any_pressed("start"):
                self.state = "title"

    # --- pause
    def draw_pause(self, s):
        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((40, 20, 70, 150))
        s.blit(ov, (0, 0))
        self.txt.draw(s, "Pause", 80, (W / 2, 180), (255, 255, 255), outline=(170, 80, 210), ow=5, title=True)
        opts = ["Continuer", "Recommencer", "Menu principal", "Sortir du jeu" if WEB else "Quitter le jeu"]
        if self.any_pressed("u"):
            self.pause_sel = (self.pause_sel - 1) % len(opts)
            self.snd.play("menu")
        if self.any_pressed("d"):
            self.pause_sel = (self.pause_sel + 1) % len(opts)
            self.snd.play("menu")
        for i, o in enumerate(opts):
            on = i == self.pause_sel
            self.txt.draw(s, ("> " + o + " <") if on else o, 42 if on else 34, (W / 2, 300 + i * 70),
                          (255, 240, 120) if on else (255, 255, 255), outline=(110, 50, 150), ow=3)
        if self.any_pressed("start"):
            self.paused = False
        elif self.any_pressed("f"):
            self.snd.play("valide")
            self.paused = False
            if self.pause_sel == 1:
                if self.state == "adventure":
                    self.start_adventure(self.adv.idx)
                else:
                    self.lan = Launcher(self, self.ridx, self.lan.easy)
            elif self.pause_sel == 2:
                self.state = "title"
            elif self.pause_sel == 3:
                return self.leave()


if __name__ == "__main__":
    Game().run()
    pygame.quit()
