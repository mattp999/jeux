"""Musique de « Licorne » (composée pour le jeu) : douce et joyeuse, en RÉ MAJEUR, 120 BPM.
Même machine à musique que les jeux des koalas, avec une nouvelle mélodie qui sautille dans la prairie.
Notation : chaque mesure = 8 croches. "-" = la note continue, "." = silence.
"""
import math
import random

RATE = 22050
BPM = 120
EIGHTH = 60 / BPM / 2

LEAD = [
    # A : Licorne trotte dans la prairie
    "F#5 . A5 . F#5 E5 D5 .",
    "E5 . F#5 G5 A5 - . .",
    "B5 . A5 . G5 F#5 E5 .",
    "F#5 - E5 . D5 - . .",
    "F#5 . A5 . F#5 E5 D5 .",
    "E5 . F#5 G5 A5 - . .",
    "B5 . D6 . A5 . F#5 .",
    "E5 - - . D5 . . .",
    # B : un muffin ! (et le Boulet de canon)
    "G5 . G5 A5 B5 . G5 .",
    "A5 . F#5 . D5 . . .",
    "G5 . B5 . D6 . B5 .",
    "A5 - - . . . . .",
    "B5 . A5 . G5 . F#5 .",
    "E5 . G5 . F#5 . E5 .",
    "D5 . F#5 . A5 . C#6 .",
    "D6 - - . . . . .",
]
CHORDS = ["D", "A", "G", "D", "D", "A", "G", "A",
          "G", "D", "G", "A", "G", "A", "D", "D"]
CHORD_NOTES = {"D": (62, 66, 69), "G": (62, 67, 71), "A": (61, 64, 69)}
BASS = {"D": (50, 57), "G": (43, 50), "A": (45, 52)}

NOTE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def midi_of(name):
    n = NOTE[name[0]]
    rest = name[1:]
    if rest.startswith("#"):
        n += 1
        rest = rest[1:]
    elif rest.startswith("b"):
        n -= 1
        rest = rest[1:]
    return 12 * (int(rest) + 1) + n


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


TS = 1024


def _table(kind):
    t = []
    for i in range(TS):
        p = i / TS
        if kind == "square":
            v = 1.0 if p < 0.5 else -1.0
        elif kind == "pulse":
            v = 1.0 if p < 0.2 else -0.25
        elif kind == "tri":
            v = 4 * p - 1 if p < 0.5 else 3 - 4 * p
        elif kind == "saw":
            v = 2 * p - 1
        else:
            v = math.sin(2 * math.pi * p)
        t.append(v)
    return t


TAB = {k: _table(k) for k in ("square", "pulse", "tri", "saw", "sine")}


def render():
    nbars = len(LEAD)
    n = int(nbars * 8 * EIGHTH * RATE)
    buf = [0.0] * (n + RATE)
    rng = random.Random(5)

    def tone(t0, dur, f, vol, wave, decay=0.0, rel=0.02, attack=0.004):
        tab = TAB[wave]
        i0 = int(t0 * RATE)
        m = int((dur + rel) * RATE)
        d_n = int(dur * RATE)
        a_n = max(1, int(attack * RATE))
        r_n = max(1, int(rel * RATE))
        ph = 0.0
        inc = f * TS / RATE
        for i in range(m):
            env = i / a_n if i < a_n else 1.0
            if decay:
                env *= math.exp(-decay * i / RATE)
            if i >= d_n:
                env *= max(0.0, 1 - (i - d_n) / r_n)
            ph += inc
            buf[i0 + i] += tab[int(ph) % TS] * env * vol

    def xylo(t0, f, vol):
        # xylophone : sinus qui s'éteint vite + petit « toc » aigu
        tone(t0, 0.32, f, vol, "sine", decay=9)
        tone(t0, 0.05, f * 4, vol * 0.25, "sine", decay=40)

    def noise(t0, dur, vol, hp=False):
        i0 = int(t0 * RATE)
        m = int(dur * RATE)
        prev = 0.0
        for i in range(m):
            v = rng.random() * 2 - 1
            if hp:
                v, prev = v - prev, v
            buf[i0 + i] += v * vol * (1 - i / m) ** 2

    def kick(t0):
        i0 = int(t0 * RATE)
        ph = 0.0
        for i in range(int(0.14 * RATE)):
            t = i / RATE
            ph += (50 + 120 * math.exp(-t * 35)) / RATE
            buf[i0 + i] += math.sin(2 * math.pi * ph) * 0.8 * math.exp(-t * 20)

    def slide_whistle(t0, f0, f1, dur, vol=0.12):
        i0 = int(t0 * RATE)
        ph = 0.0
        m = int(dur * RATE)
        for i in range(m):
            t = i / m
            ph += (f0 * (f1 / f0) ** t) / RATE
            buf[i0 + i] += math.sin(2 * math.pi * ph) * vol * math.sin(math.pi * t)

    for b, line in enumerate(LEAD):
        toks = line.split()
        k = 0
        while k < 8:
            tok = toks[k]
            if tok in ("-", "."):
                k += 1
                continue
            j = k + 1
            while j < 8 and toks[j] == "-":
                j += 1
            t0 = (b * 8 + k) * EIGHTH
            f = hz(midi_of(tok))
            xylo(t0, f, 0.30)
            if j - k >= 2:                      # notes tenues : un peu de cuivre en plus
                tone(t0, (j - k) * EIGHTH * 0.9, f / 2, 0.07, "saw", decay=2.5)
            if b >= 8:                          # refrain : cuivres à l'octave
                tone(t0, (j - k) * EIGHTH * 0.8, f, 0.06, "pulse", decay=4)
            k = j

    for b, ch in enumerate(CHORDS):
        lo, hi = BASS[ch]
        for beat in range(4):
            t0 = (b * 8 + beat * 2) * EIGHTH
            # basse « oum » sur les temps, accord « pa » à contretemps
            tone(t0, EIGHTH * 0.8, hz(lo if beat % 2 == 0 else hi), 0.30, "tri", decay=5)
            tone(t0, EIGHTH * 0.8, hz(lo if beat % 2 == 0 else hi), 0.10, "square", decay=8)
            for m in CHORD_NOTES[ch]:
                tone(t0 + EIGHTH, EIGHTH * 0.4, hz(m), 0.045, "square", decay=12)
            # batterie : galop
            if beat % 2 == 0:
                kick(t0)
            else:
                noise(t0, 0.11, 0.30)
            noise(t0, 0.03, 0.08, hp=True)
            noise(t0 + EIGHTH, 0.03, 0.06, hp=True)
            noise(t0 + EIGHTH * 1.5, 0.02, 0.05, hp=True)
    # sifflet à coulisse en fin de phrase, et roulement de caisse claire
    slide_whistle(3 * 8 * EIGHTH + 5 * EIGHTH, 500, 1300, 0.35)
    slide_whistle(11 * 8 * EIGHTH + 5 * EIGHTH, 1400, 600, 0.35)
    for b in (7, 15):
        for k2 in (5, 6):      # « pouet pouet » de clown
            tone((b * 8 + k2) * EIGHTH, EIGHTH * 0.7, hz(52 if k2 == 5 else 55), 0.10, "square", decay=6)
            tone((b * 8 + k2) * EIGHTH, EIGHTH * 0.7, hz(64 if k2 == 5 else 67), 0.07, "saw", decay=6)
    for k in range(6):
        noise((15 * 8 + 2 + k) * EIGHTH, 0.08, 0.22)

    out = buf[:n]
    for i, v in enumerate(buf[n:n + int(0.1 * RATE)]):
        out[i] += v
    y = 0.0
    for i in range(n):
        y += 0.65 * (out[i] - y)
        out[i] = y
    peak = max(abs(v) for v in out) or 1.0
    return [v / peak * 0.85 for v in out]


if __name__ == "__main__":
    import time
    import wave
    from array import array
    t = time.time()
    x = render()
    print("durée %.1f s, fabriquée en %.1f s" % (len(x) / RATE, time.time() - t))
    w = wave.open("musique_apercu.wav", "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(RATE)
    w.writeframes(array("h", [int(v * 30000) for v in x]).tobytes())
    w.close()
