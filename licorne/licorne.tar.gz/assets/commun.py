"""Outils communs : texte, manettes/clavier, syllabes, petits dessins (repris de « Le trésor de la Popotamie »)."""
import math
import os
import sys

import pygame

W, H = 1280, 720
WEB = sys.platform == "emscripten"          # la version qui tourne dans un navigateur (pygbag)


def base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def clamp(v, a, b):
    return a if v < a else b if v > b else v


# ----------------------------------------------------------------------------
# Syllabes (pour faire apparaître le texte au rythme de la parole)
# ----------------------------------------------------------------------------
VOW = set("aeiouyàâäéèêëîïôöùûüœAEIOUYÀÂÄÉÈÊËÎÏÔÖÙÛÜŒ0123456789")


def syllables(text):
    marks = []
    n = len(text)
    i = 0
    while i < n:
        if text[i] in VOW:
            j = i
            while j < n and text[j] in VOW:
                j += 1
            k = j
            while k < n and text[k].isalpha() and text[k] not in VOW:
                k += 1
            ws = i
            while ws > 0 and text[ws - 1].isalpha():
                ws -= 1
            prev_v = any(c in VOW for c in text[ws:i])
            at_end = k >= n or not text[k].isalpha()
            tail = text[j:k].lower()
            if text[i:j].lower() == "e" and at_end and prev_v and tail in ("", "s", "nt") and marks:
                marks[-1] = k
            else:
                marks.append(k if at_end else j)
            i = j
        else:
            i += 1
    return marks


# ----------------------------------------------------------------------------
# Texte
# ----------------------------------------------------------------------------
class Txt:
    def __init__(self):
        self.fonts = {}
        self.cache = {}

    # police ronde et lisible (différente de la Popotamie), avec des polices de secours
    FONTS = ("berlinsansfbdemi", "arialrounded", "segoeuiblack", "arialblack", "verdana")
    TITLE_FONTS = ("showcardgothic", "cooperblack", "berlinsansfbdemi", "arialblack")

    def font(self, size, title=False):
        key = (size, title)
        if key not in self.fonts and WEB:
            # dans le navigateur : les polices gratuites du dossier « polices » (pas de polices Windows)
            try:
                f = pygame.font.Font(os.path.join(base_dir(), "polices", "LuckiestGuy.ttf" if title else "Fredoka.ttf"), size)
                if not title:
                    f.set_bold(True)
                self.fonts[key] = f
            except Exception:
                self.fonts[key] = pygame.font.Font(None, size + 8)
        if key not in self.fonts:
            avail = set(pygame.font.get_fonts())
            names = [n for n in (self.TITLE_FONTS if title else self.FONTS) if n in avail]
            f = pygame.font.SysFont(names[0], size) if names else pygame.font.Font(None, size + 8)
            self.fonts[key] = f
        return self.fonts[key]

    def render(self, text, size, color=(255, 255, 255), outline=(40, 20, 70), ow=2, title=False):
        key = (text, size, color, outline, ow, title)
        img = self.cache.get(key)
        if img:
            return img
        if len(self.cache) > 700:
            self.cache.clear()
        f = self.font(size, title)
        base = f.render(text, True, color)
        if outline:
            img = pygame.Surface((base.get_width() + ow * 2, base.get_height() + ow * 2), pygame.SRCALPHA)
            o = f.render(text, True, outline)
            for dx in (-ow, 0, ow):
                for dy in (-ow, 0, ow):
                    if dx or dy:
                        img.blit(o, (dx + ow, dy + ow))
            img.blit(base, (ow, ow))
        else:
            img = base
        self.cache[key] = img
        return img

    def draw(self, surf, text, size, pos, color=(255, 255, 255), anchor="center", outline=(40, 20, 70), ow=2, title=False):
        img = self.render(text, size, color, outline, ow, title)
        r = img.get_rect(**{anchor: pos})
        surf.blit(img, r)
        return r

    def wrap(self, text, size, maxw):
        f = self.font(size)
        words = []
        for w in text.split(" "):
            if words and w and all(c in "!?:;»…" for c in w):
                words[-1] += " " + w
            else:
                words.append(w)
        lines, cur = [], ""
        for w in words:
            t = (cur + " " + w) if cur else w
            if f.size(t)[0] > maxw and cur:
                lines.append(cur)
                cur = w
            else:
                cur = t
        if cur:
            lines.append(cur)
        return lines


# ----------------------------------------------------------------------------
# Manettes / clavier
# ----------------------------------------------------------------------------
class Device:
    def __init__(self, kind, joy=None, num=0):
        self.kind = kind
        self.joy = joy
        self.cur = {}
        self.prev = {}
        self.f_rel = 99
        self.name = {"kb": "Clavier", "kb2": "Clavier ZQSD", "touch": "Écran tactile"}.get(kind, "Manette %d" % num)

    def poll(self, keys):
        self.prev = self.cur
        c = {}
        if self.kind == "kb":
            c["l"] = keys[pygame.K_LEFT]
            c["r"] = keys[pygame.K_RIGHT]
            c["u"] = keys[pygame.K_UP]
            c["d"] = keys[pygame.K_DOWN]
            c["f"] = keys[pygame.K_SPACE] or keys[pygame.K_RETURN] or keys[pygame.K_KP_ENTER]
            c["b"] = keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL] or keys[pygame.K_x]      # le bouton du lasso
            c["start"] = keys[pygame.K_ESCAPE] or keys[pygame.K_p]
        elif self.kind == "kb2":
            c["l"] = keys[pygame.K_q] or keys[pygame.K_a]
            c["r"] = keys[pygame.K_d]
            c["u"] = keys[pygame.K_z] or keys[pygame.K_w]
            c["d"] = keys[pygame.K_s]
            c["f"] = keys[pygame.K_f] or keys[pygame.K_LSHIFT]
            c["b"] = keys[pygame.K_g]
        elif self.kind == "touch":
            c = {k: True for k in self.joy.held}          # les boutons touchés sur l'écran
        else:
            j = self.joy
            try:
                na = j.get_numaxes()
                ax = j.get_axis(0) if na > 0 else 0
                ay = j.get_axis(1) if na > 1 else 0
                hx, hy = j.get_hat(0) if j.get_numhats() > 0 else (0, 0)
                nb = j.get_numbuttons()
                c["l"] = ax < -0.45 or hx < 0
                c["r"] = ax > 0.45 or hx > 0
                c["u"] = ay < -0.6 or hy > 0
                c["d"] = ay > 0.6 or hy < 0
                # A et X : sauter ;  B, Y et les gâchettes du haut (LB, RB) : seulement le Boulet de canon
                c["f"] = any(j.get_button(i) for i in (0, 2) if i < nb)
                c["b"] = any(j.get_button(i) for i in (1, 3, 4, 5) if i < nb)
                # Échap = boutons Select (Back) et Start ; appuyer sur les joysticks ne compte plus
                c["start"] = any(j.get_button(i) for i in (6, 7) if i < nb)
            except pygame.error:
                c = {}
        # anti-rebond : un bouton relâché moins de 2 images n'est pas un nouvel appui
        if c.get("f"):
            if not self.prev.get("f") and self.f_rel < 2:
                self.prev = dict(self.prev, f=True)
            self.f_rel = 0
        else:
            self.f_rel += 1
        self.cur = c

    def held(self, k):
        return bool(self.cur.get(k))

    def pressed(self, k):
        return bool(self.cur.get(k)) and not self.prev.get(k)

    def axis(self):
        return (1 if self.held("r") else 0) - (1 if self.held("l") else 0)


class Touch:
    """Les boutons à toucher sur l'écran (téléphone, tablette). Marche aussi avec la souris.
    Plusieurs doigts en même temps : on peut avancer et sauter à la fois."""
    # nom : (x, y, rayon)
    BTNS = {"l": (92, 598, 58), "r": (262, 598, 58), "u": (177, 512, 48), "d": (177, 676, 40),
            "f": (W - 112, 596, 80), "b": (W - 290, 640, 60), "start": (W // 2, 42, 32)}

    def __init__(self):
        self.fingers = {}          # doigt -> (x, y) sur l'écran du jeu
        self.held = set()
        self.used = False          # on ne montre les boutons qu'après le premier toucher
        self.show = set(self.BTNS)
        self.labels = {}
        self.btns = dict(self.BTNS)     # (la croix des menus se met dans le coin en haut à droite)

    def event(self, ev):
        t = ev.type
        if t in (pygame.FINGERDOWN, pygame.FINGERMOTION):
            self.fingers[("f", ev.finger_id)] = (ev.x * W, ev.y * H)
            self.used = True
        elif t == pygame.FINGERUP:
            self.fingers.pop(("f", ev.finger_id), None)
        elif getattr(ev, "touch", False):
            return                 # (la souris « imitée » par le doigt : déjà comptée)
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            self.fingers["m"] = ev.pos
            self.used = True
        elif t == pygame.MOUSEMOTION and "m" in self.fingers:
            self.fingers["m"] = ev.pos
        elif t == pygame.MOUSEBUTTONUP and ev.button == 1:
            self.fingers.pop("m", None)
        else:
            return
        self.update()

    def update(self):
        self.held = set()
        for (x, y) in self.fingers.values():
            for k, (bx, by, r) in self.btns.items():
                if k in self.show and (x - bx) ** 2 + (y - by) ** 2 <= (r * 1.3) ** 2:
                    self.held.add(k)

    def draw(self, surf, txt):
        if not self.used:
            return
        if not hasattr(self, "imgs"):
            self.imgs = {}
        for k, (x, y, r) in self.btns.items():
            if k not in self.show:
                continue
            on = k in self.held
            key = (k, on, self.labels.get(k))
            if key not in self.imgs:
                self.imgs[key] = self.button(k, r, on, self.labels.get(k))
            g = self.imgs[key]
            surf.blit(g, (x - r - 4, y - r - 4))
            if k in ("f", "b"):
                txt.draw(surf, self.labels.get(k, "OK" if k == "f" else "Boulet"), 30 if k == "f" else 24, (x, y), (255, 255, 255), outline=(110, 50, 150), ow=3)

    def button(self, k, r, on, label=None):
        """Le dessin d'un bouton (fabriqué une seule fois)."""
        g = pygame.Surface((r * 2 + 8, r * 2 + 8), pygame.SRCALPHA)
        c = r + 4
        pygame.draw.circle(g, (255, 255, 255, 150 if on else 90), (c, c), r)
        pygame.draw.circle(g, (110, 50, 150, 200), (c, c), r, 4)
        col = (110, 50, 150, 230)
        a = r * 0.45
        if k == "l":
            pygame.draw.polygon(g, col, [(c - a, c), (c + a * 0.7, c - a), (c + a * 0.7, c + a)])
        elif k == "r":
            pygame.draw.polygon(g, col, [(c + a, c), (c - a * 0.7, c - a), (c - a * 0.7, c + a)])
        elif k == "u":
            pygame.draw.polygon(g, col, [(c, c - a), (c - a, c + a * 0.7), (c + a, c + a * 0.7)])
        elif k == "d":
            pygame.draw.polygon(g, col, [(c, c + a), (c - a, c - a * 0.7), (c + a, c - a * 0.7)])
        elif k == "start" and label == "x":
            pygame.draw.line(g, col, (c - 11, c - 11), (c + 11, c + 11), 7)       # une croix : retour / sortir
            pygame.draw.line(g, col, (c - 11, c + 11), (c + 11, c - 11), 7)
        elif k == "start":
            pygame.draw.rect(g, col, (c - 11, c - 12, 8, 24))
            pygame.draw.rect(g, col, (c + 3, c - 12, 8, 24))
        return g


# ----------------------------------------------------------------------------
# Petits outils de dessin
# ----------------------------------------------------------------------------
def oval(s, col, rect, outline=None, ow=3):
    r = pygame.Rect(rect)
    if outline:
        pygame.draw.ellipse(s, outline, r.inflate(ow * 2, ow * 2))
    pygame.draw.ellipse(s, col, r)


def star_points(cx, cy, r, rot=-math.pi / 2):
    pts = []
    for i in range(10):
        rr = r if i % 2 == 0 else r * 0.45
        a = rot + i * math.pi / 5
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    return pts


def vivid(src, k=0.45):
    """Couleurs plus vives (saturation), sans toucher au gris."""
    g = pygame.transform.grayscale(src)
    pos = src.copy()
    pos.blit(g, (0, 0), special_flags=pygame.BLEND_RGB_SUB)
    neg = g.copy()
    neg.blit(src, (0, 0), special_flags=pygame.BLEND_RGB_SUB)
    m = int(k * 255)
    pos.fill((m, m, m), special_flags=pygame.BLEND_RGB_MULT)
    neg.fill((m, m, m), special_flags=pygame.BLEND_RGB_MULT)
    out = src.copy()
    out.blit(pos, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    out.blit(neg, (0, 0), special_flags=pygame.BLEND_RGB_SUB)
    return out


_PANELS = {}


def panel(surf, rect, top=(255, 90, 170), bottom=(120, 60, 255), border=(255, 255, 255), radius=22, alpha=235):
    """Panneau du jeu : dégradé vif, bord blanc épais et ombre (style différent de la Popotamie).
    Chaque panneau n'est fabriqué qu'une fois, puis gardé (c'est beaucoup plus rapide)."""
    r = pygame.Rect(rect)
    key = (r.size, tuple(top), tuple(bottom), tuple(border), radius, alpha)
    img = _PANELS.get(key)
    if img is None:
        if len(_PANELS) > 200:
            _PANELS.clear()
        img = pygame.Surface((r.w + 12, r.h + 12), pygame.SRCALPHA)
        _panel(img, pygame.Rect(2, 2, r.w, r.h), top, bottom, border, radius, alpha)
        _PANELS[key] = img
    surf.blit(img, (r.x - 2, r.y - 2))


def _panel(surf, r, top, bottom, border, radius, alpha):
    sh = pygame.Surface((r.w + 12, r.h + 12), pygame.SRCALPHA)
    pygame.draw.rect(sh, (0, 0, 0, 80), (8, 8, r.w, r.h), border_radius=radius)
    surf.blit(sh, (r.x - 2, r.y - 2))
    g = pygame.Surface(r.size, pygame.SRCALPHA)
    for y in range(r.h):
        k = y / max(1, r.h - 1)
        c = [int(top[i] + (bottom[i] - top[i]) * k) for i in range(3)]
        g.fill(c + [alpha], (0, y, r.w, 1))
    mask = pygame.Surface(r.size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    g.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    surf.blit(g, r)
    pygame.draw.rect(surf, border, r, 5, border_radius=radius)
